#include "Widget.h"
#include "ui_widget.h"
#include <QDebug>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this); // Устанавливаем ui-форму
    //QPixmap dml,dmr, dr,dl,dkr,dkl;
    /*  Изначальная загрузка кадров */
    dml = QPixmap( ":/images/santa-right" );
    dmr = QPixmap( ":/images/santa-left" );
    dr  = QPixmap( ":/images/Duck-right" );
    dl  = QPixmap( ":/images/Duck-left" );
    dkr  = QPixmap( ":/images/Duck-right-key" );
    dkl  = QPixmap( ":/images/Duck-left-key" );
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_newGameButton_clicked()
{
    /* Создаем объект логики игры */

    if(exist_game) {
        scene->clear();
        wrenches.clear();
        disconnect(game, SIGNAL(sendRectPositions(QRect,QRect,QRect,  QVector<  game_logic::wrench * >)),this, SLOT(repaint(QRect,QRect,QRect, QVector<  game_logic::wrench * >))  );
        disconnect(game,SIGNAL(removeWrench(int)),this, SLOT(removeWrench(int)));
        disconnect(game,SIGNAL(hit(int)),this, SLOT(on_hit(int)));
        disconnect(game,SIGNAL(change_points(int)),this, SLOT(change_points(int)));
        disconnect(game,SIGNAL(change_weapons(int)),this, SLOT(change_weapons(int)));
        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(animation_repaint()));
        delete timer;
        delete scene;
        delete game;
    };
    scene = new QGraphicsScene(0,0,this->width()-30,this->height()-90);
    ui->graphicsView->setScene(scene);
    scene->setBackgroundBrush(Qt::black);
    game = new game_logic(width()-30,height()-90);
    /* Осуществляем соединение с сигналами логики */
    connect(game, SIGNAL(sendRectPositions(QRect,QRect,QRect, QVector<  game_logic::wrench * >)),this, SLOT(repaint(QRect,QRect,QRect, QVector<  game_logic::wrench * >))  );
    connect(game,SIGNAL(removeWrench(int)),this, SLOT(removeWrench(int)));
    connect(game,SIGNAL(hit(int)),this, SLOT(on_hit(int)));
    connect(game,SIGNAL(change_points(int)),this, SLOT(change_points(int)));
    connect(game,SIGNAL(change_weapons(int)),this, SLOT(change_weapons(int)));
    connect(game,SIGNAL( signal_game_over()),this, SLOT(slot_game_over()));
    /* Добавляем деда мороза */
    dedMoroz =  scene->addPixmap( dmr );
    dedMoroz->setPos(scene->sceneRect().bottomLeft().x(),
                     scene->sceneRect().bottomLeft().y()-40);
    /* Добавляем первую уточку */
    duckOne  =  scene->addPixmap(  dr  );
    duckOne->setPos(scene->sceneRect().topLeft().x(),
                    scene->sceneRect().topLeft().y());

    /* Добавляем вторую уточку */
    duckTwo  =  scene->addPixmap(  dr  );
    duckOne->setPos(scene->sceneRect().topLeft().x(),
                    scene->sceneRect().topLeft().y()+70);

    ui->labelPoints->setText("Points = 0");
    ui->labelWeapons->setText("Weapons = 50");
    this->setFocus();

    timer = new QTimer;
    timer->setInterval(60);
    connect(timer, SIGNAL(timeout()), this, SLOT(animation_repaint()));
    timer->start();

    exist_game = 1;
}


void Widget::repaint(QRect dedMoroz, QRect duckOne, QRect duckTwo, QVector<game_logic::wrench *> wrenches_from_logic){
    this->dedMoroz->setPos(dedMoroz.x(),dedMoroz.y());
    this->duckOne->setPos(duckOne.x(),duckOne.y());
    this->duckTwo->setPos(duckTwo.x(),duckTwo.y());
    QVector<game_logic::wrench *>::iterator iterator_ONE =  wrenches_from_logic.begin();
    QVector<QGraphicsPixmapItem *>::iterator iterator_TWO =  wrenches.begin();
    for(;iterator_ONE != wrenches_from_logic.end();++iterator_ONE){

        (*iterator_TWO)->setPos( (*iterator_ONE)->rectWrench->x(), (*iterator_ONE)->rectWrench->y() );
        iterator_TWO++;

    }
}

void Widget::keyPressEvent(QKeyEvent *pe){
    switch(pe->key()){
    case Qt::Key_Space:
    {
        if (game->time_push == 0 && game->game_over == false && game->ammunition > 0) {
            /*            QGraphicsPixmapItem * wrench =
                    scene->addRect(0,0
                                   , 30, 30,
                                   QPen(Qt::black),
                                   QBrush(Qt::gray)) */;
            QGraphicsPixmapItem * wrench =
                    scene->addPixmap( QPixmap( ":/images/key.png" ) );
            wrench->setPos(dedMoroz->pos().x() +30 ,dedMoroz->pos().y());
            wrenches.push_back(wrench);
            game->add_wreanch( wrench->pos().x() );
            //wrench->transform().rotate(20, Qt::Axis);
            //wrench->setr
        }


    }
        break;
    }

}

void Widget::removeWrench(int i)
{
    scene->removeItem(wrenches.at(i));
    wrenches.removeAt(i);
    // qDebug() << "remove iz GU9" << wrenches.count();
}
void Widget::on_hit(int i)
{

    //qDebug() << "on_hit" << i;
    repaint_duck(i);
}

void Widget::repaint_duck(int i)
{
    if (i == 1){

        if (game->turndedDuckOne > 0)
            duckOne->setPixmap(dkr   );
        else duckOne->setPixmap(dkr );

    }
    if (i == 2){
        if (game->turndedDuckTwo > 0)
            duckTwo->setPixmap( dkl );
        else duckTwo->setPixmap( dkl );
    }

}


void Widget::change_points(int i) {
    ui->labelPoints->setText("Points: "+QString().setNum(i));
}

void Widget::change_weapons(int i){
    ui->labelWeapons->setText("Weapons: "+QString().setNum(i));
}

void Widget::slot_game_over(){
    qDebug() << "gamover";
}

void Widget::animation_repaint(){

    static int catcherOne = 0; // Статический счетчик для обнуления ключа в руке у утки 1
    static int catcherTwo = 0; // Статический счетчик для обнуления ключа в руке у утки 2
    //поставить семафор для избежания гонки сигналов в удалении
    // Отрисовка уточки 1
    if ( ( duckOne->pixmap().toImage() != dkr.toImage() ||
           duckOne->pixmap().toImage() != dkl.toImage() ) ||
           catcherOne == 0  ){
        if (game->turndedDuckOne > 0) {
            duckOne->setPixmap( dr );
            catcherOne = 10;
        }
        else {
            duckOne->setPixmap( dl );
            catcherOne = 10;
        }
    }
    else if (catcherOne != 0 &&
             ( duckOne->pixmap().toImage() == dkr.toImage() ||
               duckOne->pixmap().toImage() == dkl.toImage() ) ) {
        catcherOne--;
    }

    // Отрисовка уточки 2
    if (  catcherTwo == 0 ){
        if (game->turndedDuckTwo > 0) {
            duckTwo->setPixmap(dr );
            catcherTwo = 10;
        }
        else {
            duckTwo->setPixmap( dl );
            catcherTwo = 10;
        }
    }
    else if ( catcherTwo != 0 &&( duckTwo->pixmap().toImage() == dkr.toImage() || duckTwo->pixmap().toImage() == dkl.toImage() )) {
       qDebug() << "sovpadenie? NE dymau!";
        catcherTwo--;
    }

    if (game->turndedMoroz > 0) {
        dedMoroz->setPixmap(  dmr  );
    }
    else {
        dedMoroz->setPixmap( dml);
    }

    // Переворачиваем ключики
    QVector<  QGraphicsPixmapItem * >::iterator it = wrenches.begin();
    for (;it != wrenches.end();it++)
    {
        QTransform rotate = (*it)->transform();
        rotate.translate( (*it)->pixmap().width()/2.0, (*it)->pixmap().height()/2.0    );
        rotate.rotate(8);
        rotate.translate( -(*it)->pixmap().width()/2.0, -(*it)->pixmap().height()/2.0   );
        (*it)->setTransform(rotate);
    }

}
