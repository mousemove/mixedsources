#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtWidgets>
#include "game_logic.h"

/*
 * Класс Widget
 * Реализация GUI
 * */

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
private:
    QGraphicsScene  * scene; // Графическая сцена для вывода игры
    QGraphicsPixmapItem * dedMoroz, * duckOne, * duckTwo;// дед мороз и уточки
    QVector<  QGraphicsPixmapItem * > wrenches; // Вектор гаечных ключей для отрисовки!
    bool exist_game = 0;//Для опредения есть игра или нет
    game_logic * game;
    Ui::Widget *ui;
    void repaint_duck(int i);
    QTimer * timer;
    //Набор QPixMap'ов
    QPixmap  dml,dmr, dr,dl,dkr,dkl;

    protected:
        virtual void keyPressEvent(QKeyEvent *);
public slots:
    void repaint(QRect dedMoroz, QRect duckOne, QRect duckTwo, QVector<  game_logic::wrench * > wrenches_from_logic); //Cлот для перерисовки данных
    void removeWrench(int i);
    void on_hit(int i);
    void change_points(int i);
    void change_weapons(int i);
    void slot_game_over( );
private slots:
    void on_newGameButton_clicked();
    void animation_repaint();
};

#endif // WIDGET_H
