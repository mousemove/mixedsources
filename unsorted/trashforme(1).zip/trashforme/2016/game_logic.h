#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

#include <QObject>
#include <QWidget>
#include <QtWidgets>
#include <QDebug>

/*
 * Класс game_logic
 * Реализация логики игры
 * */
enum position_move_wrench{RIGHT,LEFT};
class game_logic : public QObject
{
    Q_OBJECT
public:

    game_logic(qreal x, qreal y);
    ~game_logic();
    void add_wreanch(); // Добавить ключ
    struct wrench {
        QRect* rectWrench;
        position_move_wrench move;
    };
    QVector<  wrench * > wrenches; // Вектор гаечных ключей!
    unsigned int time_push = 0;// Переменная которая показывает период между выстрелом ключа
    bool game_over = false;
    int ammunition = 5;// Аммуниция ключей!
    int turndedMoroz = -2, turndedDuckOne = -3, turndedDuckTwo = -4;
private:
    qreal x, y; // Размеры игрового поля
    int points = 0; // Набранные очки
    bool amunitions_to_points = 0;// Переменная для второй стадии игры

    QRect * dedMoroz, * duckOne, * duckTwo;





signals:
    void sendRectPositions(QRect,QRect,QRect, QVector <game_logic::wrench *> );
    void removeWrench(int i);
    void hit( int i );
    void change_points(int i);
    void change_weapons(int i);
    void signal_game_over( void ); /* конец игры*/
private:
    QTimer * timer; // таймер
public slots:
    void timer_function( );// Метод таймера
    void add_wreanch(qreal x);

};

#endif // GAME_LOGIC_H
