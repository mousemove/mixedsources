#include "game_logic.h"

game_logic::game_logic(qreal x, qreal y): QObject(0){
    /* Выставка X и Y */
    this->x = x;
    this->y = y;
    /* Инициализация таймера */
    timer = new QTimer;
    timer->setInterval(15);
    connect(timer, SIGNAL(timeout()), this, SLOT(timer_function()));
    timer->start();
    //turndedMoroz = 1;
    /* Инициализация блоков QRect */
    duckOne = new QRect(0,0,60,40);
    duckTwo = new QRect(0,70,60,40);
    dedMoroz = new QRect(0,y-40, 60, 40);

}

game_logic::~game_logic( )
{
    disconnect(timer, SIGNAL(timeout()), this, SLOT(timer_function()));
}

void game_logic::timer_function( ) {
    /* Передвижение деда мороза! */
    if (dedMoroz->x() < 1) {
        turndedMoroz = -1*turndedMoroz;
    }
    if (dedMoroz->x() > x-60){
        turndedMoroz = -1*turndedMoroz;
    }
    dedMoroz->setX(dedMoroz->x() + turndedMoroz);

    /* Передвижение уточки 1! */
    if (duckOne->x() < 1) {
        turndedDuckOne = -1*turndedDuckOne;
    }
    if (duckOne->x() > x-60){
        turndedDuckOne = -1*turndedDuckOne;
    }
    duckOne->setX(duckOne->x() + turndedDuckOne);

    /* Передвижение уточки 2! */
    if (duckTwo->x() < 1) {
        turndedDuckTwo = -1*turndedDuckTwo;
    }
    if (duckTwo->x()  > x -60){
        turndedDuckTwo = -1*turndedDuckTwo;
    }
    duckTwo->setX(duckTwo->x() + turndedDuckTwo);

    /* Передвижение и внутренняя обработка гаешных ключей! */
    QVector<wrench *>::iterator it = wrenches.begin();
    for(;it != wrenches.end();++it){
        if ( (*it)->move == RIGHT ){
            (*it)->rectWrench->setX((*it)->rectWrench->x() + 1 );
            (*it)->rectWrench->setY((*it)->rectWrench->y() - 1 );
        }
        if ( (*it)->move == LEFT ){
            (*it)->rectWrench->setX((*it)->rectWrench->x() - 1 );
            (*it)->rectWrench->setY((*it)->rectWrench->y() - 1 );
        }
    }

    //Отправляем сигнал на новые координаты!
    emit sendRectPositions(*dedMoroz,*duckOne,*duckTwo, wrenches);
    //qDebug() << wrenches.count() ;
    /* Передвижение и внутренняя обработка гаешных ключей! */
    it = wrenches.begin();
    for(;it != wrenches.end();++it){
        if ( (*it)->rectWrench->y() < -30 || (*it)->rectWrench->x() < -30 || (*it)->rectWrench->x()  > this->x ){ // Если вышли за пределы карты
            emit removeWrench( wrenches.indexOf(*it) ); // Отправляем сигнал на удаление из GUI
            wrenches.erase(it); //Удаляем ключ из логики
            it = wrenches.begin();
        }
        //Проверяем наличие на нахождение рядом с уточкой 2
        else if (( (*it)->rectWrench->y() > duckTwo->y() -30 &&  (*it)->rectWrench->y() < duckTwo->y()+40 ) &&
                 ( (*it)->rectWrench->x() > duckTwo->x() -30   &&  (*it)->rectWrench->x() < duckTwo->x()+60 )           )
        {
            // qDebug() << "popadanie v 2 ";
            emit hit(2);
            points++;
            emit change_points(points);
            emit removeWrench( wrenches.indexOf(*it) ); // Отправляем сигнал на удаление из GUI
            wrenches.erase(it); //Удаляем ключ из логики
            it = wrenches.begin();
        }

        //Проверяем наличие на нахождение рядом с уточкой 1
        else  if (( (*it)->rectWrench->y() > duckOne->y() -30 &&  (*it)->rectWrench->y() < duckOne->y() +40 ) &&
                  ( (*it)->rectWrench->x() > duckOne->x() -30  &&  (*it)->rectWrench->x() < duckOne->x()+60 )           )
        {
            //qDebug() << "popadanie v 1 ";
            emit hit(1);
            points = points+2;
            emit change_points(points);
            emit removeWrench( wrenches.indexOf(*it) ); // Отправляем сигнал на удаление из GUI
            wrenches.erase(it); //Удаляем ключ из логики
            it = wrenches.begin();
        }

        // qDebug()<< wrenches.indexOf(*it);
        if (wrenches.count() == 0) break; // микро-Костыль т.к. нам приходится удалять внутри обхода с помощью итератора
    }

    //Проверяем не закончилась ли игра

    if (amunitions_to_points == true && ammunition == 0 && wrenches.count() == 0){
        game_over = true;
        emit signal_game_over();
        timer->stop();
    }

    if (amunitions_to_points == false && ammunition == 0 && wrenches.count() == 0){
        ammunition = points;
        amunitions_to_points = true;
        emit change_weapons(ammunition);
        emit change_points(points);
    }

    //Обработка счетчика выстрела
    if(time_push != 0) time_push--;


}

void game_logic::add_wreanch(qreal x)
{
    /* todo pererabotat' zdec9 logiku na bolee KPACUBYU */
    if (ammunition > 0) {
        if (time_push == 0){
            wrench * item_wrench = new wrench;
            item_wrench->rectWrench = new QRect(dedMoroz->x() +30 ,dedMoroz->y(),30,30);
            item_wrench->move = (( turndedMoroz > 0 ) ? RIGHT: LEFT);
            wrenches.push_back(item_wrench);
            time_push = 10;
            ammunition--;
            emit change_weapons(ammunition);
        }
    }

}
