#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>
#include "liferect.h"
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(int x,int y);
    ~Widget();

private slots:
    void on_pushButton_clicked();
    void on_timer_timeout();
private:
    Ui::Widget *ui;
    int x;
    int y;
    QVector< QVector<LifeRect* > > vec ;
    QGraphicsScene * scene;
    void first_paint();
    QTimer * timer;
    int count_neighbors(int pos_x, int pos_y);
};

#endif // WIDGET_H
