#include "liferect.h"

LifeRect::LifeRect(qreal x, qreal y, qreal w, qreal h, QGraphicsItem *parent):QGraphicsRectItem(x,y,w,h,parent)
{
    setBrush(QBrush(Qt::white));
}

LifeRect::~LifeRect()
{

}

void LifeRect::mousePressEvent(QGraphicsSceneMouseEvent *event){
    changeColor();
}


void LifeRect::changeColor(){
    if (this->brush().color() == Qt::white)
    {
        this->setBrush(QBrush(Qt::black));
    }
    else{
        this->setBrush(QBrush(Qt::white));
    }
}
