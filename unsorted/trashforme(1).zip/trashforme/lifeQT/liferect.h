#ifndef LIFERECT_H
#define LIFERECT_H

#include <QObject>
#include <QtWidgets>
class LifeRect : public QGraphicsRectItem
{
public:

    LifeRect(qreal x, qreal y, qreal w, qreal h, QGraphicsItem *parent = 0);
    ~LifeRect();
public:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void changeColor();
};

#endif // LIFERECT_H
