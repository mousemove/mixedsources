#include "widget.h"
#include "ui_widget.h"
//#include "liferect.h"
Widget::Widget(int x, int y) :x(x),y(y),
    QWidget(0),
    ui(new Ui::Widget)
{
    ui->setupUi(this);


}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    first_paint();
    timer = new QTimer();
    timer->setInterval(1000);
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(on_timer_timeout()));
    timer->start();
}

void Widget::first_paint(){
    scene = new QGraphicsScene(0,0,ui->graphicsView->viewport()->width(),ui->graphicsView->viewport()->height());
    vec.resize(x);
    for (int i = 0; i < x; i++){
        vec[i].resize(y);
        for (int j = 0; j < y; j++)
        {
            QGraphicsRectItem * rec = new LifeRect(0,0,scene->sceneRect().width()/(x),scene->sceneRect().height()/(y));
            scene->addItem(rec);
            rec->setPos( 0+ i*scene->width()/(x),0 + j* scene->height()/(y) );
            LifeRect * lef = dynamic_cast<LifeRect *>(rec);
            vec[i][j] = lef;
        }
    }
    ui->graphicsView->setScene(scene);
}


void Widget::on_timer_timeout(){
    int nebs ;
    QVector< LifeRect* > vectemp;
    for (int i = 0; i < x; i++){

        for (int j = 0; j < y; j++)
        {
            nebs = count_neighbors(i,j);
            if (vec[i][j]->brush().color() == Qt::white && nebs == 3){
                vectemp.push_back(vec[i][j]);
            }
            if (vec[i][j]->brush().color() == Qt::black && (nebs > 3 || nebs < 2)){
                vectemp.push_back(vec[i][j]);
            }
        }
    }

    QVector< LifeRect* >::iterator it = vectemp.begin();
    for (;it !=vectemp.end();it++){
        (*it)->changeColor();
    }
    timer->stop();
}


int Widget::count_neighbors(int pos_x, int pos_y)
{
    int j;
    int i;
    int temp_i;
    int temp_j;
    int result = 0;
    for (i = pos_x -1 ; i <= pos_x + 1; i++) {

        temp_i = i;
        if (i == -1) {temp_i = x-1;}
        else if (i == x) {temp_i = 0;}

        for (j = pos_y-1; j <= pos_y+1; j++) {
            temp_j = j;
            if (j == -1) {temp_j = y-1;}
            else if (j == y) {temp_j = 0;}
            if (vec[temp_i][temp_j]->brush().color() == Qt::black && !(temp_i == pos_x && temp_j == pos_y))
            {result++;}

        }
    }
    return result;
}
