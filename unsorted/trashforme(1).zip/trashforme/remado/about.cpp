#include "about.h"

about::about(QWidget *parent) : QWidget(parent)
{
    setupUi();

    label_rules->setText("<center>Remado.<br>by Alexey Abramov, 2015.(c)<br>Original idea - Amado(1989).<br> Version 1.0.<center>");
}

about::~about()
{

}


void about::setupUi(){
    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(this->sizePolicy().hasHeightForWidth());
    this->setSizePolicy(sizePolicy);
    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    horizontalSpacer_2 = new QSpacerItem(159, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_2, 0, 0, 1, 1);

    horizontalSpacer = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer, 0, 2, 1, 1);

    label_logo = new QLabel(this);
    logo =  QPixmap(":/images/main_logo.png");
    label_logo->setPixmap(logo);
    gridLayout->addWidget(label_logo, 0, 1, 1, 1);

    label_rules = new QLabel(this);
    QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(0);
    sizePolicy1.setHeightForWidth(label_rules->sizePolicy().hasHeightForWidth());
    label_rules->setSizePolicy(sizePolicy1);



    gridLayout->addWidget(label_rules, 1, 0, 1, 3);
    QPalette p;
    p.setColor( QPalette::Background, QColor(Qt::gray) );
    this->setPalette(p);
    setLayout(gridLayout);
    setAutoFillBackground(true);
}

void about::mousePressEvent(QMouseEvent*){
    emit to_main_menu();
}

void about::keyPressEvent(QKeyEvent *ke){
    emit to_main_menu();
}
