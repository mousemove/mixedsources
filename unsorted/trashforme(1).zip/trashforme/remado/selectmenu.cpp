#include "selectmenu.h"

selectmenu::selectmenu(QWidget *parent) : QWidget(parent)
{

    setupUi();
    connect(pushButton_Back,SIGNAL(clicked( )),this,SLOT(button_back_clicked()));
    connect(pushButton_MediumMode,SIGNAL(clicked( )),this,SLOT(button_medium_clicked()));
    connect(pushButton_easyMode,SIGNAL(clicked( )),this,SLOT(button_easy_clicked()));
    connect(pushButton_Hard,SIGNAL(clicked( )),this,SLOT(button_hard_clicked()));
    /*  Получаем рекод из "реестра" приложения */

}

void selectmenu::setupUi(){
    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(this->sizePolicy().hasHeightForWidth());
    this->setSizePolicy(sizePolicy);
    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    horizontalSpacer_2 = new QSpacerItem(127, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_2, 0, 0, 1, 2);

    label_logo = new QLabel(this);
    logo =  QPixmap(":/images/main_logo.png");
    label_logo->setPixmap(logo);
    gridLayout->addWidget(label_logo, 0, 2, 1, 1);

    horizontalSpacer = new QSpacerItem(126, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer, 0, 3, 1, 2);

    verticalSpacer = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer, 1, 2, 1, 1);

    horizontalSpacer_3 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_3, 2, 0, 1, 1);

    pushButton_easyMode = new QPushButton(this);
    pushButton_easyMode->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_easyMode->setFocusPolicy(Qt::NoFocus);
    QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(0);
    sizePolicy1.setHeightForWidth(pushButton_easyMode->sizePolicy().hasHeightForWidth());
    pushButton_easyMode->setSizePolicy(sizePolicy1);
    QFont font;
    font.setPointSize(33);
    pushButton_easyMode->setFont(font);

    gridLayout->addWidget(pushButton_easyMode, 2, 1, 1, 3);

    horizontalSpacer_4 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_4, 2, 4, 1, 1);

    verticalSpacer_2 = new QSpacerItem(20, 29, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_2, 3, 2, 1, 1);

    horizontalSpacer_6 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_6, 4, 0, 1, 1);

    pushButton_MediumMode = new QPushButton(this);
    pushButton_MediumMode->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_MediumMode->setFocusPolicy(Qt::NoFocus);
    sizePolicy1.setHeightForWidth(pushButton_MediumMode->sizePolicy().hasHeightForWidth());
    pushButton_MediumMode->setSizePolicy(sizePolicy1);
    pushButton_MediumMode->setFont(font);

    gridLayout->addWidget(pushButton_MediumMode, 4, 1, 1, 3);

    horizontalSpacer_5 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_5, 4, 4, 1, 1);

    verticalSpacer_4 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_4, 5, 2, 1, 1);

    horizontalSpacer_9 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_9, 6, 0, 1, 1);

    pushButton_Hard = new QPushButton(this);
    pushButton_Hard->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_Hard->setFocusPolicy(Qt::NoFocus);
    sizePolicy1.setHeightForWidth(pushButton_Hard->sizePolicy().hasHeightForWidth());
    pushButton_Hard->setSizePolicy(sizePolicy1);
    pushButton_Hard->setFont(font);

    gridLayout->addWidget(pushButton_Hard, 6, 1, 1, 3);

    horizontalSpacer_7 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_7, 6, 4, 1, 1);

    verticalSpacer_3 = new QSpacerItem(20, 29, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_3, 7, 2, 1, 1);

    horizontalSpacer_10 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_10, 8, 0, 1, 1);

    pushButton_Back = new QPushButton(this);
    pushButton_Back->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_Back->setFocusPolicy(Qt::NoFocus);
    sizePolicy1.setHeightForWidth(pushButton_Back->sizePolicy().hasHeightForWidth());
    pushButton_Back->setSizePolicy(sizePolicy1);
    pushButton_Back->setFont(font);

    gridLayout->addWidget(pushButton_Back, 8, 1, 1, 3);

    horizontalSpacer_8 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_8, 8, 4, 1, 1);

    verticalSpacer_5 = new QSpacerItem(20, 88, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_5, 9, 2, 1, 1);
    pushButton_easyMode->setText("Easy");
    pushButton_MediumMode->setText("Medium");
    pushButton_Hard->setText("Hard");
    pushButton_Back->setText("Back to menu");
    QPalette p;
    p.setColor( QPalette::Background, QColor(Qt::gray) );
    this->setPalette(p);
    setLayout(gridLayout);
    setAutoFillBackground(true);

}



void selectmenu::button_back_clicked(){
    emit back_to_main_menu();
}


void selectmenu::button_easy_clicked(){
    emit start_easy_game();
    qDebug() << "easy";
}




void selectmenu::button_medium_clicked(){
    emit start_medium_game();
    qDebug() << "medium";
}




void selectmenu::button_hard_clicked(){
    emit start_hard_game();
    qDebug() << "hard";
}
