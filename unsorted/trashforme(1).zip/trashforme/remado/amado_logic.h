#ifndef AMADO_LOGIC_H
#define AMADO_LOGIC_H

#include <QObject>
#include <QtWidgets>
#include <QDebug>
class amado_logic : public QObject
{
    Q_OBJECT
public:
    amado_logic(QObject *parent, unsigned int size,int time); // Конструктор игры
    enum colors{COLOR_ONE = Qt::darkCyan, COLOR_TWO = Qt::red, COLOR_THREE = Qt::yellow}; // Массив цветов окрашенных полей
    void first_paint();
private:
    QVector< QVector< amado_logic::colors > >  field; //Двумерный вектор для хранения игрового поля
    QVector< QVector< amado_logic::colors > >  model; //Двумерный вектор для хранения эталона
    QVector< QVector< bool  > >  equality; // Двумерный вектор сравнения
    void make_matrix(QVector< QVector< amado_logic::colors > > &matrix, unsigned int size);
    /* Положения текущего элемента */
    unsigned int activeX;
    unsigned int activeY;
    //Данные для таймера
    unsigned int time;
    QTimer * timer;

    void change_square_colors( uint x_one, uint y_one, uint x_two, uint y_two );
    colors fiend_no_color_in_set( colors one, colors two);
    bool check_equality();
    void game_finish();
signals:
    /* Сигналы на отправку данных для первичной отрисовки данных */
    void paint_model(QVector< QVector< amado_logic::colors > >  model, QVector< QVector< amado_logic::colors > >  field);
    void set_active(unsigned int, unsigned int);
    void repaint_field_cell(uint x, uint y, amado_logic::colors color);
    void signal_finish(unsigned int points, QVector< QVector< bool  > >  equality);
    void signal_time(unsigned int time);
public slots:
    void slot_act_down(); // Слот подачи вниз
    void slot_act_up(); // Слот подачи вверх
    void slot_act_left(); // Слот подачи влево
    void slot_act_right(); // Cлот подачи вправо
    void start_time();//Слот старта таймера
private slots:
    void timer_function();
};

#endif // AMADO_LOGIC_H
