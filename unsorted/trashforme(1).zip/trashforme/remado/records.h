#ifndef RECORDS_H
#define RECORDS_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>
class records : public QWidget
{
    Q_OBJECT
public:
    explicit records(QWidget *parent = 0);
    ~records();
private:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QLabel *label_logo;
    QLabel *label_rules;
    QPixmap logo;

    void setupUi();
protected:
    void   mousePressEvent(QMouseEvent*);
    void keyPressEvent(QKeyEvent *ke);
signals:
    void to_main_menu();
public slots:
};

#endif // RECORDS_H
