#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtWidgets>
#include "loadingwidget.h"
#include "mainmanu.h"
#include "records.h"
#include "selectmenu.h"
#include "amado2.h"
#include "gameresult.h"
#include "about.h"
class remado : public QStackedWidget
{
    Q_OBJECT

public:
    remado( );
    ~remado();
private:
    /* Виджеты используемые в программе */
    loadingWidget * load_menu; // Виджет для 5 секундной загрузки - старта программы
    mainmanu * main_menu; // Виджет главного меню.
    records * records_table; // Страничка с рекордами
    selectmenu * select_menu; // Меню выбора сложности игры
    amado2 * game_gui;
    gameresult * result_widget;
    about * about_widget;
public slots:
    /* Слоты отправляющие информацию для переключения виджета*/
    void slot_loading_animation_end();
    void slot_set_records_widget();
    void slot_set_about_widget();
    void slot_set_select_menu();
    void slot_start_easy_game();
    void slot_start_medium_game();
    void slot_start_hard_game();
    void slot_game_over(int pts);
};

#endif // WIDGET_H
