#ifndef ABOUT_H
#define ABOUT_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>

class about : public QWidget
{
    Q_OBJECT
public:
    explicit about(QWidget *parent = 0);
    ~about();
private:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QLabel *label_logo;
    QLabel *label_rules;
    QPixmap logo;

    void setupUi();

protected:
    void   mousePressEvent(QMouseEvent*);
    void keyPressEvent(QKeyEvent *ke);
signals:
    void to_main_menu();
};

#endif // ABOUT_H
