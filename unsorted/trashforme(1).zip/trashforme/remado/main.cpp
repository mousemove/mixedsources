#include "remado.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    remado w;
    w.showFullScreen();
    return a.exec();
}
