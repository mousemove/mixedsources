#include "myqgraphicsview.h"
#include <QPointF>
#include <QDebug>

MyQGraphicsView::MyQGraphicsView(QWidget *parent) :
    QGraphicsView(parent)
{
    this->setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
    this->setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
}

void MyQGraphicsView::mousePressEvent(QMouseEvent * e)
{

    mousepressed = 1;
    startX = e->globalX();
    startY = e->globalY();
    //qDebug() << "mousepress!!!!11111111111";
}

void MyQGraphicsView::mouseReleaseEvent(QMouseEvent * e)
{
    emit push();
    mousepressed = 0;
    int changeX = e->globalX() - startX;
    int changeY = e->globalY() - startY;
    if(changeX != 0 && changeY != 0){
        if (fabs(changeX) > fabs(changeY))
        {
            if (changeX < 0 ){
                emit swipeLeft();
            }
            else{
                emit swipeRight();
            }
        }
        if (fabs(changeX) < fabs(changeY))
        {

            if (changeY < 0 ){
                emit swipeUp();
            }
            else{
                emit swipeDown();
            }

        }
    }
    else
    {
         emit push_without_swipe();
    }
}



// bool MyQGraphicsView::event(QEvent *event){

//     //    if (event->type() == QEvent::KeyPress)
//     //    {
//     //        keyPressEvent(static_cast<QKeyEvent*>(event));
//     //    }

//     //    if (event->type() == QEvent::Gesture){
//     //        return gestureEvent(static_cast<QGestureEvent*>(event));
//     //    }
// qDebug() << event->type();
//     if (event->type() == QEvent::Gesture)
//        { qDebug() << "jest" ;}
//     return QWidget::event(event);

// }
