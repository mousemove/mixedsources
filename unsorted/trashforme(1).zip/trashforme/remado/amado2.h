#ifndef AMADO2_H
#define AMADO2_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>
#include "amado_logic.h"
#include "myqgraphicsview.h"
class amado2 : public QWidget
{
    Q_OBJECT
public:
    amado2(unsigned int time_start, unsigned int matrix_size, unsigned int time_coeff, QWidget *parent);

private:
    amado_logic * game;
    QGraphicsScene  * scene; // Графическая сцена для вывода игры
    bool game_exist = 0; // Временная переменная для проверки на существование игры
    bool game_active = 0;
    bool game_in_finish = 0;
    unsigned int points = 0; // Очки
    unsigned int matrix_size;
    unsigned int live_count = 3;
    unsigned int time_start ;
    unsigned int time_coeff ;
    QGraphicsTextItem * pointText;
    QGraphicsTextItem * timerText;
    QGraphicsTextItem * livesText;
    /*  Двойные вектора с  rect-ами для модели и игрового поля*/
    QVector< QVector< QGraphicsRectItem * > >  model_gui;
    QVector< QVector< QGraphicsRectItem * > >  field_gui;
    void set_current_block(unsigned int x,unsigned int y);
    void delete_select_block();
    void check_equality();


signals:
    void act_down(); // Сигнал подачи вниз
    void act_up(); // Сигнал подачи вверх
    void act_left(); // Сигнал подачи влево
    void act_right(); // Cигнал подачи вправо
    void start_timer_logic();
    void die_die_die(int pts);
public slots:

    /* Cлот для первичной отрисовки игровых полей*/

    void paint_model(QVector< QVector< amado_logic::colors > >  model, QVector< QVector< amado_logic::colors > >  field);
    void slot_set_active_block(unsigned int x, unsigned int y);
    void slot_repaint_field_cell(unsigned int x, unsigned int y, amado_logic::colors c);
    void slot_game_finish(unsigned int time, QVector< QVector< bool  > >  equality);
    void slot_update_time(unsigned int time);
    void tap_to_start(); //Сигнал старта по тапу!
protected:
    virtual void keyPressEvent(QKeyEvent *);
private slots:


    void on_newButton_clicked();

    void on_upButton_clicked();

    void on_downButton_clicked();

    void on_rightButton_clicked();

    void on_leftButton_clicked();
    /* Часть для отрисовки ГУЯ */
private:

    QGridLayout *gridLayout;
    QPushButton *upButton;
    QPushButton *leftButton;
    QPushButton *downButton;
    QPushButton *rightButton;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    MyQGraphicsView *graphicsView;

    void setupUi();
};

#endif // AMADO2_H
