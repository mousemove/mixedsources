
#include "amado_logic.h"

amado_logic::amado_logic(QObject *parent, unsigned int size, int time) : QObject(parent), activeX(0), activeY(0),time(time)
{
    /* Заполнение игрового поля цветами */
    make_matrix(field,size);
    make_matrix(model,size);
    //model = field;
    emit paint_model(model,field);
    /* Создаем timer */
    timer = new QTimer();
    timer->setInterval(1000);
    connect(timer, SIGNAL(timeout()), this, SLOT(timer_function()));

}

void amado_logic::make_matrix(QVector<QVector<colors> > &matrix, unsigned int size){

    matrix.resize(size); // Задаем размер матрицы
    unsigned int newcolor; //Переменная для заполнения матрицы значениями
    for(unsigned int i = 0; i < size; ++i)
    {
        matrix[i].resize(size); //Задаем размер строки
        for(unsigned int j = 0; j < size; ++j){

            newcolor = rand() % 3;

            switch( newcolor ){
            case 0:
                matrix[i][j]  = COLOR_ONE;
                break;
            case 1:
                matrix[i][j]  = COLOR_TWO;
                break;
            case 2:
                matrix[i][j]  = COLOR_THREE;
                break;
            }
        }
    }


}





void amado_logic::first_paint(){
    emit paint_model(field,model);
}



/* Слоты обработки действий пользователя */

void amado_logic::slot_act_down(){

    if (activeX < field.size() - 1){

        activeX =  activeX+1;
        emit set_active(activeX,activeY);
        //            qDebug() << activeX << activeY << "current";
        //        qDebug() << activeX-1 << activeY << "old";
        change_square_colors(activeX,activeY,activeX-1,activeY);
    }
}

void amado_logic::slot_act_up(){

    if (activeX > 0){

        activeX = activeX-1;
        emit set_active(activeX,activeY);
        //           qDebug() << activeX << activeY << "current";
        //       qDebug() << activeX+1 << activeY << "old";
        change_square_colors(activeX,activeY,activeX+1,activeY);
    }
}

void amado_logic::slot_act_right(){

    if (activeY  <  field.size() - 1){

        activeY = activeY+1;
        emit set_active(activeX,activeY);
        //            qDebug() << activeX << activeY << "current";
        //        qDebug() << activeX << activeY-1 << "old";
        change_square_colors(activeX,activeY,activeX,activeY-1);
    }
}

void amado_logic::slot_act_left(){
    // qDebug() << activeX << activeY << "old";
    if (activeY > 0){

        activeY = activeY-1;
        emit set_active(activeX,activeY);
        //            qDebug() << activeX << activeY << "current";
        //        qDebug() << activeX << activeY+1 << "old";
        change_square_colors(activeX,activeY,activeX,activeY+1);
    }
}

void amado_logic::change_square_colors(uint x_one, uint y_one, uint x_two, uint y_two)
{

    colors color_ONE = field[x_one][y_one];
    colors color_TWO = field[x_two][y_two];
    if (color_ONE == color_TWO)
    {

    }
    else
    {
        colors c = fiend_no_color_in_set(color_ONE, color_TWO);
        field[x_one][y_one] = c;
        emit repaint_field_cell(x_one,y_one,c);
        if (check_equality() == true) {
            //timer->stop();
            game_finish();
        }
    }
}


amado_logic::colors  amado_logic::fiend_no_color_in_set( colors one, colors two){
    colors c;
    colors EnumValues[3] = {COLOR_ONE, COLOR_TWO, COLOR_THREE}; // Создаем массив т.к. перебирать внутри енама напрямую нельзя!
    for (int i = 0; i  < 3; i++ )
    {
        if (one != EnumValues[i] && two != EnumValues[i] )
        {
            c = EnumValues[i];
            break;
        }
    }
    return c;
}


void amado_logic::timer_function(){
    emit signal_time(--time);
    if  (0 == time){
        game_finish();
    }
}

bool amado_logic::check_equality(){
    for (int i =0 ; i < model.size();i++){
        for (int j =0 ; j < model.size();j++){
            if (model[i][j] != field[i][j])   return false;
        }
    }
    return true;
}

void amado_logic::game_finish(){
    qDebug() << "finish";
    timer->stop();
    equality.resize(model.size());
    for(unsigned int i = 0; i < model.size(); ++i)
    {
        equality[i].resize(model.size()); //Задаем размер строки
        for(unsigned int j = 0; j < model.size(); ++j){
            if (model[i][j] == field[i][j]) {equality[i][j] = true;}
                    else equality[i][j] = false;

        }
    }

    emit signal_finish(time, equality);

}


void amado_logic::start_time()//Слот старта таймера
{
timer->start();
}
