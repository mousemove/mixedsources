#include "amado_logic.h"
#include "amado2.h"
#include <QDebug>
#include <QtWidgets>

amado2::amado2(unsigned int time_start, unsigned int matrix_size, unsigned int time_coeff, QWidget *parent) :
    QWidget(parent),
    time_start(time_start),
    matrix_size(matrix_size),
    time_coeff(time_coeff)
{
    setupUi();


    //    connect(upButton,SIGNAL(clicked()),this,SLOT(on_upButton_clicked()));
    //    connect(rightButton,SIGNAL(clicked()),this,SLOT(on_rightButton_clicked()));
    //    connect(leftButton,SIGNAL(clicked()),this,SLOT(on_leftButton_clicked()));
    //    connect(downButton,SIGNAL(clicked()),this,SLOT(on_downButton_clicked()));
    connect(graphicsView,SIGNAL(push()),this,SLOT(tap_to_start()));

    qDebug() << this->width() << this->height();// kakogo  100-300????????????????????
    qDebug() << graphicsView->width() << graphicsView->height(); // kakogo 100-300?????????????
    //graphicsView->resize();
    /* После конструктора, как слот - выставляется верное значение
    В чем баг??????????????7*/
    graphicsView->setFocusPolicy(Qt::NoFocus);
    on_newButton_clicked();
   // this->installEventFilter(keyPressEater);
}


void amado2::on_newButton_clicked()
{
    game_in_finish = 0;
    disconnect(graphicsView,SIGNAL(push_without_swipe()),this,SLOT(on_newButton_clicked()));
    connect(graphicsView,SIGNAL(push()),this,SLOT(tap_to_start()));
    if (game_exist == 1){
        disconnect(game,
                   SIGNAL(paint_model(QVector<QVector<amado_logic::colors> >,QVector<QVector<amado_logic::colors> >)),
                   this,
                   SLOT(paint_model(QVector<QVector<amado_logic::colors> >,QVector<QVector<amado_logic::colors> >)));
        scene->clear();

        disconnect(game,SIGNAL(set_active(unsigned int, unsigned int)),this, SLOT(slot_set_active_block(unsigned int, unsigned int)));
        disconnect(game, SIGNAL(repaint_field_cell(uint,uint,amado_logic::colors)),this,SLOT(slot_repaint_field_cell(uint,uint,amado_logic::colors)));
        disconnect(game,SIGNAL(signal_finish(uint,QVector<QVector<bool> >)), this, SLOT(slot_game_finish(uint,QVector<QVector<bool> >)));
        disconnect(game,SIGNAL(signal_time(uint)),this, SLOT(slot_update_time(uint)));
        disconnect(this,SIGNAL(start_timer_logic()),game,SLOT(start_time()));
        delete game;
    }
    if (live_count == 0){
        emit die_die_die(points);
        return;
    }


    game = new amado_logic( this,matrix_size,time_start ); // создаем новый объект игры
    game_exist = 1; // Выставляем переменную о том что игра существует
    game_active = 0; //До тапа - нулю!
    /* Осуществляем сигнально-слотовые соединения для игры и GUI */

    connect(game,
            SIGNAL(paint_model(QVector<QVector<amado_logic::colors> >,QVector<QVector<amado_logic::colors> >)),
            this,
            SLOT(paint_model(QVector<QVector<amado_logic::colors> >,QVector<QVector<amado_logic::colors> >)));
    connect(this, SIGNAL(act_down(  )),game, SLOT(slot_act_down(  )));
    connect(this, SIGNAL(act_up(    )),game, SLOT(slot_act_up(  )));
    connect(this, SIGNAL(act_right( )),game, SLOT(slot_act_right(   )));
    connect(this, SIGNAL(act_left(  )),game, SLOT(slot_act_left(    )));
    connect(game,SIGNAL(set_active(unsigned int, unsigned int)),this, SLOT(slot_set_active_block(unsigned int, unsigned int)));
    connect(game, SIGNAL(repaint_field_cell(uint,uint,amado_logic::colors)),this,SLOT(slot_repaint_field_cell(uint,uint,amado_logic::colors)));
    connect(game,SIGNAL(signal_finish(uint,QVector<QVector<bool> >)), this, SLOT(slot_game_finish(uint,QVector<QVector<bool> >)));
    connect(game,SIGNAL(signal_time(uint)),this, SLOT(slot_update_time(uint)));
    connect(this,SIGNAL(start_timer_logic()),game,SLOT(start_time()));
    /* Создаем графическую сцену */
    scene = new QGraphicsScene(0,0,this->width()-50,this->height()-50);
    //qDebug() << scene->sceneRect().width() << scene->sceneRect().height();
    QLinearGradient gradient(0, height(), width(),0);
        gradient.setColorAt(0, Qt::black);
    gradient.setColorAt(0.8, QColor::fromRgb(85,73,1));
    gradient.setColorAt(1, Qt::black);

   // gradient.setColorAt(0, QColor::fromRgb(35,30,30));
  // gradient.setColorAt(0.25, Qt::gray);
     //   gradient.setColorAt(0.5, QColor::fromRgb(48,43,43));
       //     gradient.setColorAt(0.75, Qt::gray);
     //   gradient.setColorAt(1, QColor::fromRgb(58,53,53));
    scene->setBackgroundBrush(gradient);
    graphicsView->setScene(scene);
    game->first_paint();
    //qDebug() << "delaem 1 fokus";
    this->setFocusPolicy(Qt::StrongFocus);

}



void amado2::paint_model(QVector< QVector< amado_logic::colors > >  model, QVector< QVector< amado_logic::colors > >  field){
    qDebug() << "paint_model";
    /* Выполняем отрисовку модели 1 */
    model_gui.resize(model.size());
    field_gui.resize(field.size());
    qreal startPaintModel_x;
    qreal startPaintModel_y;
    qreal height_blockModel;
    qreal startPaintField_x;
    qreal startPaintField_y;
    qreal height_blockField;
    unsigned int i = 0;
    unsigned int j = 0;
    height_blockModel =  (scene->sceneRect().width() < scene->sceneRect().height() ?
                              (scene->sceneRect().width()/1.1 / model.size())-5 :
                              (scene->sceneRect().height()/1.6 / model.size())-5) ;
    startPaintModel_x = scene->sceneRect().center().x() -
            (height_blockModel * model.size()/2 +
             ((model.size()/2) * 5)
             );
    startPaintModel_y = 0;

    for( i = 0; i < model.size(); ++i)
    {
        field_gui[i].resize(model.size());
        for( j = 0; j < model.size(); ++j){
            QGraphicsRectItem * square = scene->addRect( 0,0,height_blockModel,height_blockModel,QPen( (Qt::GlobalColor)model[i][j] ),QBrush( (Qt::GlobalColor)model[i][j] ) ) ;
            square->setPos( startPaintModel_x + (j * (height_blockModel+5)), startPaintModel_y + (i * (height_blockModel+5)));

            //square->setFlag(QGraphicsItem::ItemIsMovable);
            field_gui[i][j] = square;

        }
    }

    /* Отрисовка линии разделения и текста */

    //QGraphicsLineItem * line = scene->addLine(0,startPaintModel_y + (i * (height_blockModel+5)) + 20,scene->sceneRect().width(),startPaintModel_y + (i * (height_blockModel+5))+20,QPen(Qt::white));
    QGraphicsLineItem * line = scene->addLine(0,0,scene->sceneRect().width(), 0,QPen(Qt::white));
    line->setPos(0,startPaintModel_y + (i * (height_blockModel+5)) + 20);
    pointText = scene->addText("");
    pointText->setPlainText("Points: " + QString().setNum(points));
    pointText->setFont(QFont("Arial",13));
    pointText->setDefaultTextColor(Qt::white);
    pointText->setPos(0,line->scenePos().y()+20);
    timerText = scene->addText("Time: "+QString().setNum(time_start));
    timerText->setFont(QFont("Arial",13));
    timerText->setDefaultTextColor(Qt::white);
    timerText->setPos(0,line->scenePos().y()+50);
    livesText = scene->addText("Lives: "+QString().setNum(live_count));
    livesText->setFont(QFont("Arial",13));
    livesText->setDefaultTextColor(Qt::white);
    livesText->setPos(0,line->scenePos().y()+80);
    QGraphicsTextItem * tmodel = scene->addText("Model:");
    tmodel->setPos(scene->sceneRect().center().x(),line->scenePos().y()+20);
    tmodel->setFont(QFont("Arial",13));
    tmodel->setDefaultTextColor(Qt::green);
    /* Отрисовка блока игровое поле */
    height_blockField =  (scene->sceneRect().width() < scene->sceneRect().height() ?
                              (scene->sceneRect().width()/2/1.1 / field.size())-3 :
                              (scene->sceneRect().height()/2/1.6 / field.size())-3 ) ;

    //startPaintField_x = scene->sceneRect().center().x() + (scene->sceneRect().center().x()/2) -
    //          (height_blockModel * field.size()/2 +
    //           ((field.size()/2) * 3)
    //          );
    startPaintField_x = tmodel->scenePos().x();

    startPaintField_y = line->scenePos().y()+45;
    //  qDebug() << height_blockField << startPaintField_x << startPaintField_y;
    for( i = 0; i < field.size(); ++i)
    {
        model_gui[i].resize(field.size());
        for( j = 0; j < field.size(); ++j){
            QGraphicsRectItem * square = scene->addRect( 0,0,height_blockField,height_blockField,QPen( (Qt::GlobalColor)field[i][j] ),QBrush( (Qt::GlobalColor)field[i][j] ) ) ;
            square->setPos( startPaintField_x + (j * (height_blockField+3)), startPaintField_y + (i * (height_blockField+3)));
            //square->setPen(Q);
            square->setFlag(QGraphicsItem::ItemIsMovable);
            model_gui[i][j] = square;
        }
    }

    set_current_block(0,0);
    //this->setFocus();
}


void amado2::set_current_block(unsigned int x,unsigned int y){
    delete_select_block();
    QPen pen = QPen(Qt::gray);
    pen.setWidth(10);
    field_gui[x][y]->setPen( pen  );
}

void amado2::delete_select_block(){
    for( int i = 0; i < model_gui.size(); ++i)
    {
        for( int j = 0; j < model_gui.size(); ++j){
            model_gui[i][j]->setPen( QPen( )    );
            field_gui[i][j]->setPen(  QPen( )     );
        }
    }
}

void amado2::on_upButton_clicked()
{
    emit act_up();
    this->setFocus();
    if (game_in_finish == 1){
        on_newButton_clicked();
    }
}

void amado2::on_downButton_clicked()
{
    emit act_down();
    this->setFocus();
    if (game_in_finish == 1){
        on_newButton_clicked();
    }
}

void amado2::on_rightButton_clicked()
{
    emit act_right();
    this->setFocus();
    if (game_in_finish == 1){
        on_newButton_clicked();
    }
}

void amado2::on_leftButton_clicked()
{
    emit act_left();
    this->setFocus();
    if (game_in_finish == 1){
        on_newButton_clicked();
    }
}




void amado2::keyPressEvent(QKeyEvent *pe){
    qDebug() << "eta xyun9 inactive/WHAAATT";
    if (game_active == 0){
        tap_to_start();
    }

    //if (game_exist == 1){
    switch(pe->key()){

    case Qt::Key_Up:
    {
        emit act_up();
    }
        break;
    case Qt::Key_Down:
    {
        emit act_down();
    }
        break;
    case Qt::Key_Left:
    {
        emit act_left();
    }
        break;
    case Qt::Key_Right:
    {
        emit act_right();
    }
        break;
    case Qt::Key_Escape:
    {
        emit die_die_die(points);
    }
        break;
    case Qt::Key_Back:
    {
        emit die_die_die(points);
    }
        break;
    default:
    {
        if (game_in_finish == 1){

            on_newButton_clicked();
        }

    }
        break;
    }
    //}
}


void amado2::slot_set_active_block(unsigned int x, unsigned int y)
{

    set_current_block(x,y);

}

void amado2::slot_repaint_field_cell(unsigned int x, unsigned int y, amado_logic::colors c){
    // qDebug() << "delaem repaint!!!" << c;
    QBrush brush = QBrush( (Qt::GlobalColor)c);
    field_gui[x][y]->setBrush( brush );

}

void amado2::slot_game_finish(unsigned int time, QVector< QVector< bool  > >  equality){

    /* Процедура вычисления очков */
    bool full_eq = 1;
    points += time_coeff*time;

    for(unsigned int i = 0; i < equality.size(); ++i)
    {
        for(unsigned int j = 0; j < equality.size(); ++j){
            if (equality[i][j] == true) {
                points +=10;
                model_gui[i][j]->setBrush(Qt::white);

            }
            else {full_eq = 0;}
        }
    }

    pointText->setPlainText("Points: " + QString().setNum(points));
    if (full_eq == 0) {
        live_count -= 1;
        livesText->setPlainText("Lives: "+QString().setNum(live_count));
    }

    //Новый time_coeff,time,lives
    time_coeff += 1;
    if (time_start != 1){
        time_start -= 1;
    }
    game_in_finish = 1;
    disconnect(this, SIGNAL(act_down(  )),game, SLOT(slot_act_down(  )));
    disconnect(this, SIGNAL(act_up(    )),game, SLOT(slot_act_up(  )));
    disconnect(this, SIGNAL(act_right( )),game, SLOT(slot_act_right(   )));
    disconnect(this, SIGNAL(act_left(  )),game, SLOT(slot_act_left(    )));
    disconnect(graphicsView,SIGNAL(swipeDown()),this,SLOT(on_downButton_clicked()));
    disconnect(graphicsView,SIGNAL(swipeUp()),this,SLOT(on_upButton_clicked()));
    disconnect(graphicsView,SIGNAL(swipeLeft()),this,SLOT(on_leftButton_clicked()));
    disconnect(graphicsView,SIGNAL(swipeRight()),this,SLOT(on_rightButton_clicked()));

    connect(graphicsView,SIGNAL(push_without_swipe()),this,SLOT(on_newButton_clicked()));

}

void amado2::slot_update_time(unsigned int time){
    //qDebug() << "perekrawivaem time" << time;
    timerText->setPlainText("Time: " + QString().setNum(time));
}

void amado2::tap_to_start(){
    if (game_active == 0){
        emit start_timer_logic();
        disconnect(graphicsView,SIGNAL(push()),this,SLOT(tap_to_start()));
        connect(graphicsView,SIGNAL(swipeDown()),this,SLOT(on_downButton_clicked()));
        connect(graphicsView,SIGNAL(swipeUp()),this,SLOT(on_upButton_clicked()));
        connect(graphicsView,SIGNAL(swipeLeft()),this,SLOT(on_leftButton_clicked()));
        connect(graphicsView,SIGNAL(swipeRight()),this,SLOT(on_rightButton_clicked()));
        //this->setFocus();
        game_active = 1;
    }

}




/*Выставка UI*/
void amado2::setupUi(){


    this->setGeometry(0,0,parentWidget()->width(),parentWidget()->height());


    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    //    upButton = new QPushButton(this);
    //    QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Preferred);
    //    sizePolicy.setHorizontalStretch(0);
    //    sizePolicy.setVerticalStretch(0);
    //    sizePolicy.setHeightForWidth(upButton->sizePolicy().hasHeightForWidth());
    //    upButton->setSizePolicy(sizePolicy);

    //    gridLayout->addWidget(upButton, 1, 3, 1, 1, Qt::AlignRight);

    //    leftButton = new QPushButton(this);
    //    sizePolicy.setHeightForWidth(leftButton->sizePolicy().hasHeightForWidth());
    //    leftButton->setSizePolicy(sizePolicy);

    //    gridLayout->addWidget(leftButton, 2, 2, 1, 1);

    //    downButton = new QPushButton(this);
    //    sizePolicy.setHeightForWidth(downButton->sizePolicy().hasHeightForWidth());
    //    downButton->setSizePolicy(sizePolicy);

    //    gridLayout->addWidget(downButton, 3, 3, 1, 1);

    //    rightButton = new QPushButton(this);
    //    sizePolicy.setHeightForWidth(rightButton->sizePolicy().hasHeightForWidth());
    //    rightButton->setSizePolicy(sizePolicy);

    // gridLayout->addWidget(rightButton, 2, 4, 1, 1, Qt::AlignVCenter);

    horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    // gridLayout->addItem(horizontalSpacer, 2, 5, 1, 1);

    horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    //gridLayout->addItem(horizontalSpacer_2, 2, 0, 1, 1);

    graphicsView = new MyQGraphicsView(this);

    QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(0);
    sizePolicy1.setHeightForWidth(graphicsView->sizePolicy().hasHeightForWidth());
    graphicsView->setSizePolicy(sizePolicy1);

    gridLayout->addWidget(graphicsView, 0, 0, 1, 6);
    QPalette p;
    p.setColor( QPalette::Background, QColor(Qt::gray) );
    this->setPalette(p);
    setLayout(gridLayout);
    setAutoFillBackground(true);

    //    upButton->setText( "UP" );
    //    leftButton->setText("LEFT");
    //    downButton->setText("DOWN");
    //    rightButton->setText("RIGHT");
}


