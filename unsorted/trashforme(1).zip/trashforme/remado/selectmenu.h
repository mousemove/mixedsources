#ifndef SELECTMENU_H
#define SELECTMENU_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>

class selectmenu : public QWidget
{
    Q_OBJECT
public:
    explicit selectmenu(QWidget *parent = 0);
private:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_logo;
    QPixmap logo;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_easyMode;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_MediumMode;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *verticalSpacer_4;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *pushButton_Hard;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButton_Back;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_5;
    void setupUi();
signals:
    void back_to_main_menu();
    void start_easy_game();
    void start_medium_game();
    void start_hard_game();
public slots:
    void button_back_clicked();
    void button_easy_clicked();
    void button_medium_clicked();
    void button_hard_clicked();
};

#endif // SELECTMENU_H
