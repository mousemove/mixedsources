#include "mainmanu.h"

mainmanu::mainmanu(QWidget *parent) : QWidget(parent)
{
    setupUi();
    connect(pushButton_Exit,SIGNAL(clicked()),this,SLOT(on_button_exit_clicked()));
    connect(pushButton_About,SIGNAL(clicked()),this,SLOT(on_button_about_clicked()));
    connect(pushButton_Records,SIGNAL(clicked()),this,SLOT(on_button_records_clicked()));
    connect(pushButton_newGame,SIGNAL(clicked()),this,SLOT(on_button_new_clicked()));
}

mainmanu::~mainmanu()
{

}




void mainmanu::on_button_new_clicked(){
    emit set_select_menu();
}

void mainmanu::on_button_about_clicked(){
    emit set_about_widget();
}

void mainmanu::on_button_records_clicked(){

    emit set_records_table();

}

void mainmanu::on_button_exit_clicked(){
    exit(0); // выходим с кодом ошибки 0
}




/* Частичто генерируемая функция установки пользовательского интерфейса */
void mainmanu::setupUi(){

    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(this->sizePolicy().hasHeightForWidth());
    this->setSizePolicy(sizePolicy);
    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    horizontalSpacer_2 = new QSpacerItem(127, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_2, 0, 0, 1, 2);

    label_logo = new QLabel(this);
    logo =  QPixmap(":/images/main_logo.png");
    label_logo->setPixmap(logo);
    gridLayout->addWidget(label_logo, 0, 2, 1, 1);

    horizontalSpacer = new QSpacerItem(126, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer, 0, 3, 1, 2);

    verticalSpacer = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer, 1, 2, 1, 1);

    horizontalSpacer_3 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_3, 2, 0, 1, 1);

    pushButton_newGame = new QPushButton(this);
    pushButton_newGame->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
    sizePolicy1.setHorizontalStretch(0);
    sizePolicy1.setVerticalStretch(0);
    sizePolicy1.setHeightForWidth(pushButton_newGame->sizePolicy().hasHeightForWidth());
    pushButton_newGame->setSizePolicy(sizePolicy1);
    QFont font;
    font.setPointSize(33);
    pushButton_newGame->setFont(font);
    pushButton_newGame->setFocusPolicy(Qt::NoFocus);
    gridLayout->addWidget(pushButton_newGame, 2, 1, 1, 3);

    horizontalSpacer_4 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_4, 2, 4, 1, 1);

    verticalSpacer_2 = new QSpacerItem(20, 29, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_2, 3, 2, 1, 1);

    horizontalSpacer_6 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_6, 4, 0, 1, 1);

    pushButton_Records = new QPushButton(this);
    pushButton_Records->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    sizePolicy1.setHeightForWidth(pushButton_Records->sizePolicy().hasHeightForWidth());
    pushButton_Records->setSizePolicy(sizePolicy1);
    pushButton_Records->setFont(font);
    pushButton_Records->setFocusPolicy(Qt::NoFocus);

    gridLayout->addWidget(pushButton_Records, 4, 1, 1, 3);

    horizontalSpacer_5 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_5, 4, 4, 1, 1);

    verticalSpacer_4 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_4, 5, 2, 1, 1);

    horizontalSpacer_9 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_9, 6, 0, 1, 1);

    pushButton_About = new QPushButton(this);
    sizePolicy1.setHeightForWidth(pushButton_About->sizePolicy().hasHeightForWidth());
    pushButton_About->setSizePolicy(sizePolicy1);
    pushButton_About->setFont(font);
    pushButton_About->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_About->setFocusPolicy(Qt::NoFocus);
    gridLayout->addWidget(pushButton_About, 6, 1, 1, 3);

    horizontalSpacer_7 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_7, 6, 4, 1, 1);

    verticalSpacer_3 = new QSpacerItem(20, 29, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_3, 7, 2, 1, 1);

    horizontalSpacer_10 = new QSpacerItem(47, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_10, 8, 0, 1, 1);

    pushButton_Exit = new QPushButton(this);
    pushButton_Exit->setStyleSheet(
                "QPushButton {"
                " color: #000;"
                "border: 1px solid #555;"
                " border-radius: 11px;"
                " padding: 5px;"
                "background: qradialgradient(cx: 0.3, cy: -0.4,"
                " fx: 0.3, fy: -0.4,"
                "  radius: 1.35, stop: 0 #FFCD00, stop: 1 #FFE05F);"
                " min-width: 80px;"
                " }"
                "QPushButton:pressed {"
                "background: qradialgradient(cx: 0.4, cy: -0.1,"
                "fx: 0.4, fy: -0.1,"
                "radius: 1.35, stop: 0 #AE8B01, stop: 1 #9F9052);"
                "}"
                );
    pushButton_Exit->setFocusPolicy(Qt::NoFocus);
    sizePolicy1.setHeightForWidth(pushButton_Exit->sizePolicy().hasHeightForWidth());
    pushButton_Exit->setSizePolicy(sizePolicy1);
    pushButton_Exit->setFont(font);

    gridLayout->addWidget(pushButton_Exit, 8, 1, 1, 3);

    horizontalSpacer_8 = new QSpacerItem(46, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_8, 8, 4, 1, 1);

    verticalSpacer_5 = new QSpacerItem(20, 88, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer_5, 9, 2, 1, 1);
    pushButton_newGame->setText("New Game");
    pushButton_Records->setText("Rules");
    pushButton_About->setText("About");
    pushButton_Exit->setText("Exit");
    QPalette p;
    p.setColor( QPalette::Background, QColor(Qt::gray) );
    this->setPalette(p);
    setLayout(gridLayout);
    setAutoFillBackground(true);
}
