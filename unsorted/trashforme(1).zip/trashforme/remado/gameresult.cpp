#include "gameresult.h"

gameresult::gameresult(QWidget *parent,int points) : QWidget(parent),points(points),settings("QBapps","remado")
{
    setupUi();
    settings.beginGroup("/settings");
    record = settings.value("/record",0).toInt();
    if (record < points ){
        settings.setValue("/record",points);
    }
    record = settings.value("/record",0).toInt();
    label_3->setText("Record: "+QString().setNum(record));
}

gameresult::~gameresult()
{

}

void gameresult::setupUi(){
    QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(this->sizePolicy().hasHeightForWidth());
    this->setSizePolicy(sizePolicy);
    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    horizontalSpacer_2 = new QSpacerItem(159, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer_2, 0, 0, 1, 1);

    label = new QLabel(this);
    label = new QLabel(this);
    logo =  QPixmap(":/images/main_logo.png");
    label ->setPixmap(logo);
    gridLayout->addWidget(label, 0, 1, 1, 1);

    horizontalSpacer = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

    gridLayout->addItem(horizontalSpacer, 0, 2, 1, 1);

    verticalSpacer = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Minimum);

    gridLayout->addItem(verticalSpacer, 1, 1, 1, 1);

    label_2 = new QLabel(this);
    QFont font;
    font.setPointSize(33);
    label_2->setFont(font);

    gridLayout->addWidget(label_2, 2, 1, 1, 1,Qt::AlignHCenter);

    verticalSpacer_3 = new QSpacerItem(20, 170, QSizePolicy::Minimum, QSizePolicy::Expanding);

    gridLayout->addItem(verticalSpacer_3, 3, 1, 1, 1);

    label_3 = new QLabel(this);
    label_3->setFont(font);

    gridLayout->addWidget(label_3, 4, 1, 1, 1,Qt::AlignHCenter);

    verticalSpacer_2 = new QSpacerItem(20, 171, QSizePolicy::Minimum, QSizePolicy::Expanding);

    gridLayout->addItem(verticalSpacer_2, 5, 1, 1, 1);
    label_2->setText("Score: "+QString().setNum(points) );
    QPalette p;
    p.setColor( QPalette::Background, QColor(Qt::gray) );
    this->setPalette(p);
    setLayout(gridLayout);
    setAutoFillBackground(true);
}


void   gameresult::mousePressEvent(QMouseEvent*){
    emit back_to_main_menu();
}

void gameresult::keyPressEvent(QKeyEvent *  ke){
    emit back_to_main_menu();
}
