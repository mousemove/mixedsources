#include "remado.h"
/* Класс-маршрутизатор игры */
remado::remado( )
{
    //Инициализируем виджет загрузки
    load_menu = new loadingWidget(this);
    addWidget(load_menu);
    connect(load_menu,SIGNAL(animation_end()),this,SLOT(slot_loading_animation_end()));
    //Инициализируем виджет главного меню
    main_menu = new mainmanu(this);
    addWidget(main_menu);
    connect(main_menu,SIGNAL(set_records_table()),this, SLOT(slot_set_records_widget()));
    connect(main_menu,SIGNAL(set_select_menu()),this, SLOT(slot_set_select_menu()));
    connect(main_menu,SIGNAL(set_about_widget()),this, SLOT(slot_set_about_widget()));
    //Инициализируем виджет правила игры
    records_table = new records(this);
    addWidget(records_table);
    connect(records_table,SIGNAL(to_main_menu()),this, SLOT(slot_loading_animation_end()));
    //Инициализируем виджет о игре
    about_widget = new about(this);
    addWidget(about_widget);
    connect(about_widget,SIGNAL(to_main_menu()),this, SLOT(slot_loading_animation_end()));
    //Инициализируем виджет меню выбора режима игры
    select_menu = new selectmenu(this);
    addWidget(select_menu);
    connect(select_menu,SIGNAL(back_to_main_menu()),this,SLOT(slot_loading_animation_end()));
    connect(select_menu,SIGNAL(start_easy_game()),this,SLOT(slot_start_easy_game()));
    connect(select_menu,SIGNAL(start_medium_game()),this,SLOT(slot_start_medium_game()));
    connect(select_menu,SIGNAL(start_hard_game()),this,SLOT(slot_start_hard_game()));
    /* Выставляем первый виджет - загрузочное меню! */
    setCurrentWidget(load_menu);
}

remado::~remado()
{

}

void remado::slot_loading_animation_end(){
    setCurrentWidget(main_menu);
}


void remado::slot_set_records_widget(){
    setCurrentWidget(records_table);
}

void remado::slot_set_select_menu(){
    setCurrentWidget(select_menu);
}


void remado::slot_start_easy_game(){
    game_gui = new amado2( 50,4,10,this );
    addWidget(game_gui);
    connect(game_gui,SIGNAL(die_die_die(int)),this,SLOT(slot_game_over(int)));
    setCurrentWidget(game_gui);
    game_gui->setFocus();
}

void remado::slot_start_medium_game(){
    game_gui = new amado2( 70,5,15,this );
    addWidget(game_gui);
    connect(game_gui,SIGNAL(die_die_die(int)),this,SLOT(slot_game_over(int)));
    setCurrentWidget(game_gui);
     game_gui->setFocus();
}

void remado::slot_start_hard_game(){
    game_gui = new amado2( 90,6,20,this );
    addWidget(game_gui);
    setCurrentWidget(game_gui);
    connect(game_gui,SIGNAL(die_die_die(int)),this,SLOT(slot_game_over(int)));
     game_gui->setFocus();
}


void remado::slot_game_over(int pts){
    disconnect(game_gui,SIGNAL(die_die_die(int)),this,SLOT(slot_game_over(int)));

    result_widget = new gameresult(this,pts);
    addWidget(result_widget);
    setCurrentWidget(result_widget);
    connect(result_widget,SIGNAL(back_to_main_menu()),this,SLOT(slot_loading_animation_end()));
    this->removeWidget( game_gui );

    delete game_gui;

}
void remado::slot_set_about_widget(){
    setCurrentWidget(about_widget);
}
