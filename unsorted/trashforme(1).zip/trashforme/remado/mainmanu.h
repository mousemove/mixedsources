#ifndef MAINMANU_H
#define MAINMANU_H

#include <QWidget>
#include <QtWidgets>
#include <QDebug>

class mainmanu : public QWidget
{
    Q_OBJECT
public:
    explicit mainmanu(QWidget *parent = 0);
    ~mainmanu();
private:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_logo;
    QPixmap logo;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_newGame;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_Records;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *verticalSpacer_4;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *pushButton_About;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *pushButton_Exit;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_5;
    void setupUi();
signals:
    void set_records_table();
    void set_select_menu();
    void set_about_widget();
private slots:
    void on_button_new_clicked();
    void on_button_about_clicked();
    void on_button_records_clicked();
    void on_button_exit_clicked();

};

#endif // MAINMANU_H
