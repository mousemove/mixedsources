#ifndef GAMERESULT_H
#define GAMERESULT_H

#include <QtWidgets>
#include <QDebug>
class gameresult : public QWidget
{
    Q_OBJECT

public:
    gameresult(QWidget *parent = 0,int points = 0);
    ~gameresult();
private:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label;
    QPixmap logo;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_3;
    QLabel *label_3;
    QSpacerItem *verticalSpacer_2;
    void setupUi();
    int points;
    QSettings settings;
    int record;
protected:
    void   mousePressEvent(QMouseEvent*);
    void keyPressEvent(QKeyEvent *ke);
signals:
    void back_to_main_menu();
public slots:
};

#endif // GAMERESULT_H
