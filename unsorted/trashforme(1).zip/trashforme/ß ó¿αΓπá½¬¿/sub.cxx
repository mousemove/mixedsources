/*
 * sub.cxx
 * 
 * Copyright 2021 user <user@lnx-vdi-a223>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <chrono>
#include <map>
#include <set>
using namespace std;
class Solution {
public:
    static int lengthOfLongestSubstring(string s) {
		int start = 0;
		 int finish = s.length();
		int result = 0;
		for(int i = start;i < finish;)
		{
			int currentMax = 0;
			map<char,int> counters;
			int z = i;
			char l = s[i];
			while(i < finish)
			{
				if (counters.find(s[i]) != counters.end())
				{ 
					if (currentMax > result) result = currentMax;
					cout << "decro i = " << i << " " << s[i] << endl;
					i = counters[s[i]]+1;break;
					//if(s[i] == l) {i = counters[s[i]]+1;break;}
					//if( s[i] != s[i-1] )i--;
					break;		
				}
				else 
				{
					cout << "inc " << s[i] << " " << currentMax << " " << i << endl;
					counters[s[i]] = i;
					i++;
					currentMax++;
				}
				
			}
			if (currentMax > result) result = currentMax;
			
		}
      return result;  
    }
};

int main(int argc, char **argv)
{
	
	auto begin = std::chrono::steady_clock::now();
	
	auto result = Solution::lengthOfLongestSubstring("wobgrovw");
	auto end = std::chrono::steady_clock::now();
	auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);
	cout << result << endl;
	std::cout << "The time: " << elapsed_ms.count() << " ms\n";
	return 0;
}

