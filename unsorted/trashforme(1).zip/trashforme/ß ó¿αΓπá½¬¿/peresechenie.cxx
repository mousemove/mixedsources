/*
 * sub.cxx
 * 
 * Copyright 2021 user <user@lnx-vdi-a223>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <chrono>
#include <vector>
using namespace std;
struct pt {
	int x, y;
};
int area (pt a, pt b, pt c) {
	return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}
 
 bool intersect_1 (int a, int b, int c, int d) {
	if (a > b)  swap (a, b);
	if (c > d)  swap (c, d);
	return max(a,c) <= min(b,d);
}
 
bool intersect (pt a, pt b, pt c, pt d) {
	return intersect_1 (a.x, b.x, c.x, d.x)
		&& intersect_1 (a.y, b.y, c.y, d.y)
		&& area(a,b,c) * area(a,b,d) <= 0
		&& area(c,d,a) * area(c,d,b) <= 0;
}
class Solution {
public:
   static bool isSelfCrossing(const vector<int>& x) {
	/*   int highX  =0;
	   int highY = 0;
	   int X1 = 0;
	   int Y2 = x[0];
       int X3 = -1*x[1];
       int Y4 = -1*x[2]+x[0];
       cout << X1 << " " << Y2 << " " << X3 << " " << Y4 << endl;
       int firstlineX0 = 0;
       int firstlineY0 = 0;
       int firstlineX1 = 0;
       int firstlineY1 = x[0];
       
       int secondlineX0 = X3;
       int secondlineY0 = Y4;
       int secondlineX1 = Y4;
       int secondlineY1 = X3+x[3];
       cout << "fl:: " << firstlineX0 << " " << firstlineY0 << " " << firstlineX1 << " " << firstlineY1 << endl;
       cout << "sl:: " << secondlineX0 << " " << secondlineY0 << " " << secondlineX1 << " " << secondlineY1 << endl;
       pt a;a.x = firstlineX0; a.y = firstlineY0;
       pt b;b.x = firstlineX1; b.y = firstlineY1;
       pt c;c.x = secondlineX0; c.y = secondlineY0;
       pt d;d.x = secondlineX1; d.y = secondlineY1; */
       //переменные и т.п.
        
	vector<pt> points;
	pt p({0,0});
	points.push_back(p);
	
	int offsetX = 0;
	int offsetY = 0;
	char wise = 0;
	for(int i = 0;i < x.size();i++)
	{
		
		pt p;
		p.x = offsetX +(i%2 ? (wise == 0 || wise ==3 ? 1 : -1)*x[i] : 0);
		p.y = offsetY + (i % 2 ? 0  : (wise == 0 || wise ==3 ? 1 : -1)*x[i]);
		offsetX = p.x;
		offsetY = p.y;
		points.push_back(p);
		wise++;
		if(wise == 4) wise = 0;
	}
	if(points.size() < 0 ) return false;
	for(auto i : points)
	cout << i.x << " " << i.y << "  " << points.size() << endl;
	
	for(int i = 0; i < points.size()-4;i++)
	{
		cout << "4ek intersekt" << endl;
		for(auto j = i+3 ;j < points.size()-1;j++)
		{
			cout << "X::::: " << i << " " << i+1 << " " << j << " " << j+1 << " "  << points.size() << endl;
		if (intersect(points[i],points[i+1],points[j],points[j+1])) return true;	
		}
		
		//if (intersect(points[i],points[i+1],points[i+3],points[i+4])) return true;
	}
       return false;
    }
};

int main(int argc, char **argv)
{
	
	auto begin = std::chrono::steady_clock::now();
	
	cout << Solution::isSelfCrossing({1}) << endl;
	auto end = std::chrono::steady_clock::now();
	auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);
	std::cout << "The time: " << elapsed_ms.count() << " ms\n";
	return 0;
}


