/*
 * addtwonumbers.cxx
 * 
 * Copyright 2021 user <user@lnx-vdi-a223>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */


#include <iostream>
#include <chrono>
using namespace std;

  struct ListNode {
      int val;
      ListNode *next;
      ListNode() : val(0), next(nullptr) {}
      ListNode(int x) : val(x), next(nullptr) {}
      ListNode(int x, ListNode *next) : val(x), next(next) {}
  };
 
class Solution {
public:
   static ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        //ListNode* l = new ListNode(7,new ListNode(10));
        
        ListNode* l = new ListNode();
        ListNode* first = l;
        bool vume = false;
        while(l1 || l2 || vume)
        {
			int sum = 0;
			
			if(l1){
			sum += l1->val;
			l1 = l1->next;
			
		    }
			if(l2)  {
			sum +=l2->val;	
			l2 = l2->next;
			
			}
			if(vume)  {sum +=1;vume = false;}
			if(sum > 9) {sum = sum-10;vume=true;}
			l->val = sum;
			if(l1 || l2 || vume)
			{
			l->next = new ListNode();
			l = l->next;}
		}
        
        return first;
    }
};


int main(int argc, char **argv)
{
	
	
	//ListNode * first = new ListNode(2,new ListNode(4,new ListNode(3)));
	//ListNode * second = new ListNode(5,new ListNode(6,new ListNode(4)));
		//ListNode * first = new ListNode(0);
	//ListNode * second = new ListNode(0);
		ListNode * first = new ListNode(9,new ListNode(9,new ListNode(9,new ListNode(9,new ListNode(9,new ListNode(9,new ListNode(9)))))));
	ListNode * second = new ListNode(9,new ListNode(9,new ListNode(9,new ListNode(9))));
		 auto begin = std::chrono::steady_clock::now();
	
	
	
	
	ListNode * k = Solution::addTwoNumbers(first,second);
	
	
	
	auto end = std::chrono::steady_clock::now();
		  auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);

	do
	{
	 cout << k->val  << " ";
	 k  = k->next;
	}while(k);
	cout << endl;

  std::cout << "The time: " << elapsed_ms.count() << " ms\n";
	
	return 0;
}

