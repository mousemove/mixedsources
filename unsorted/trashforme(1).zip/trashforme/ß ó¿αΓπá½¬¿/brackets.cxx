/*
 * sub.cxx
 * 
 * Copyright 2021 user <user@lnx-vdi-a223>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */

// (()
#include <iostream>
#include <chrono>
#include <vector>
#include <stack>
using namespace std;
class Solution {
public:
    static bool isValid(string s) {

		stack<int> Circle;
		stack<int> Round;
		stack<int> Figure;
		for(unsigned i = 0; i < s.length();i++)
		{
			
			
			if (s[i] == '[') {Round.push(i);}
			else if (s[i] == '(') {Circle.push(i);}
			else if (s[i] == '{') {Figure.push(i);}
			else if (s[i] == ']') {if((!Round.empty()) && ((!Figure.empty() ? Round.top() > Figure.top() : 1) && (!Circle.empty() ?Round.top() > Circle.top() : 1) ) ) {Round.pop();} else {return false;}}
			else if (s[i] == ')') {if((!Circle.empty()) && ((!Figure.empty() ?Circle.top() > Figure.top() : 1 ) && (!Round.empty() ?Circle.top() > Round.top() : 1) ) ) {Circle.pop();} else {return false;}}
			else if (s[i] == '}') {if((!Figure.empty()) && ((!Circle.empty() ? Figure.top() > Circle.top() : 1) && (!Round.empty() ?Figure.top() > Round.top() : 1) ) ) {Figure.pop();} else {return false;}}
		}
        return (Circle.empty() && Round.empty() && Figure.empty());
    }
};

int main(int argc, char **argv)
{
	
	auto begin = std::chrono::steady_clock::now();
	
	cout << Solution::isValid("[[[]") << endl;
	
	auto end = std::chrono::steady_clock::now();
	auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);
	std::cout << "The time: " << elapsed_ms.count() << " ms\n";
	return 0;
}
