#ifndef ABSTRACTELEMENT_H
#define ABSTRACTELEMENT_H
/* Абстрактный класс элемента */
#include <QObject>
#include <QtWidgets>
#include <QDebug>
#include "abstractshell.h"
class abstractElement : public QObject
{
    Q_OBJECT
public:
    abstractElement( QSize size, int formWidth, int formHeight  );
protected:
    /* Позиции по X и Y элемента */
    double x;//позиция вернего левого угла по оси X
    double y; // позиция верхнего левого угла по оси Y
    int health_points = 1; // HP мишени!(изначально 1)
    /* Стартовые позиции - для нелинейных функций они крайне нужны. */
    unsigned int profit = 100;
    int health_up = 0;
    int start_x ;
    int start_y;
    QTimer * timer;
    unsigned int posMov = 0; //временная версия - позиционирование движения(0 - вправо/влево, 1 - вверх/вниз)
    /* Размеры формы для рисования */
    int formWidth;
    int formHeight ;
    /*  Типы элементов*/
    int up;
    int right;
    QSize size; // Размер элемента на графической сцене
    QPixmap  PixMap; // Картиночка
    QPixmap boomPix;
    unsigned int boomTickTack = 80;
    QGraphicsPixmapItem * item; // Хренотень в графической сцене
    bool entrance = false;
    virtual  void change_entrance(); // Функция для обработки состояния entrance
    void leave(); // Покинули область рисования
public:  
    int get_damage(abstractShell * shell); /* TODODODOTOTOTOTODODOODDODODOTOTOTOODODDODO 99% что она будет виртуальной */
    void SetElement ( QGraphicsPixmapItem * gitem ) ;
    /* Виртуальная функция */
    virtual void Change ( void ) = 0; // Функция пересчета позиции
    /*Возвращающие функции */
    QPixmap  getPixItem(); // Получение qgraphicspixmapitem
    /* Получить позиции */
    double getX();
    double getY();
    bool getUp();
    bool getRight();
    int getPosMov();
    void stopTimer();
    unsigned int getProfit();
    QPixmap getBoomPix();
    unsigned int getBoomTimer();
    QSize getSize();
    int getHP();
    /* Выставить некоторые позиции */
    bool getEntrance();
    void setStartX(int x);
    void setStartY(int y);
    void setUp(int up);
    void setRight(int right);
    void setX(int x);
    void setY(int y);
    int getHU();
    QGraphicsPixmapItem * getQGPI();
signals:
    void goodbye( abstractElement *);
public slots:
};

#endif // ABSTRACTELEMENT_H
