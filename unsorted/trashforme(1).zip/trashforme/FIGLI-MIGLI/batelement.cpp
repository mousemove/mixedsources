#include "batelement.h"

batElement::batElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/Bat.png").scaled(size);
    this->health_points  = 1;

}

/* Функция которая изменяет положение элемента */
void batElement::Change( void ){
    this->x = x + this->right;
    this->item->setPos(x,y);
    this->change_entrance();
}



