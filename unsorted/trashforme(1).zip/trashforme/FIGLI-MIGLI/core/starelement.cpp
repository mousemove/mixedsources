#include "starelement.h"
starElement::starElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/christmas_star.png").scaled(size);

}

/* Функция которая изменяет положение элемента */
void starElement::Change( void ){
        this->x = this->x + this->right + this->right*cos(y/16);
        this->y = this->y + this->up;
        this->item->setPos(x,y);
        this->change_entrance();
}
