#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

#include <QObject>
#include <QtWidgets>
#include "abstractelement.h"
#include "batelement.h"
#include "pirateelement.h"
#include "starelement.h"
#include "abstractshell.h"
#include "smileshell.h"
#include "appleshell.h"
#include "healthelement.h"
#include "goldelement.h"
#include "bigelement.h"
#include "generationelement.h"
#include "generationmicroelement.h"
class game_logic : public QObject
{
    Q_OBJECT
public:
    explicit game_logic(QObject *parent, int width, int height);
    enum elements_enum { BAT,PIRATE,STAR,HEALTH,GOLD,BIG,GEN }; // для фабричной функции
    enum shells_enum   { TOMATO,APPLE};
    unsigned int maximumMissed = 20; // максимальное число которое можно пропустить
    unsigned int points = 0;// набранные очки в игре
    unsigned int missed = 0;// пропущено мишеней
    QTimer * timer;
private:
    /* Данные игровой составляющей -> в дальнейшем будут подаваться через конструктор */
    QVector<abstractElement *> elements;
    QVector<abstractElement *> elementsToDelete; // Во избежании утечек памяти удаляем новым циклом!!!
    QVector<abstractShell *> shells;
    abstractShell * activeShell; // Вынесен из qvector во избежании выстрела себе в ногу!
    QVector< QPair<abstractElement *, abstractShell *> > clashPair;// формируемая пара для расчета столкновения
    QVector<abstractShell *> shellsToDelete; // Во избежании утечек памяти удаляем новым циклом!!!
    void new_shell();
    int height;
    int width;

    bool exShell = 0; // Присутствует ли снаряд на карте!!!!!!!!!!
    void check_clashes( ); // Наполнение вектора пар clashPair
    void processing_clashes();
signals:
    void set_in_scene( abstractElement * );
    void delete_in_scene(QGraphicsPixmapItem *);
    void set_in_scene_shell( abstractShell * );
    void set_temp_picture(int,int,QPixmap, unsigned int);
    void repaintPoints(unsigned int);
    void repaintMissed(unsigned int);
public slots:
    void add_element( elements_enum element ); //Временный перенос в паблик слоты
    void delete_element_from_goodbye(abstractElement * bat); // элемент самовыпилился
    void add_element_to_kill(abstractElement * bat);
    void add_shell_to_kill(abstractShell * bat);
    void add_static_element(double x, double y);
    void add_bomb_el(double x,double y);
private slots:
    void timer_function();
public:
    void push_shell(double angleX, double angleY);
};

#endif // GAME_LOGIC_H
