#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "myqgraphicsview.h"
#include <QDebug>
#include "game_logic.h"
#include "abstractelement.h"
#include "abstractshell.h"
namespace Ui {
class Widget;
}

class migli : public MyQGraphicsView
{
    Q_OBJECT

public:
    explicit migli( );
    ~migli();

private:
    QGraphicsScene * scene;
    game_logic * game;
    bool game_is_start = false;
    QVector< QPair<QGraphicsPixmapItem *,unsigned int> > tp;
    QVector< QPair<QGraphicsPixmapItem *,unsigned int> > tpTempToDelete;
    void draw_info_zone();
    QGraphicsTextItem * pointsText;//Текст с очками
    QGraphicsTextItem * missedText;//Текст о пропущенных мишенях
public slots:
    void new_game();
    void slot_set_element_in_scene( abstractElement * el);
    void slot_set_shell_in_scene( abstractShell * el);
    void slot_delete_element_in_scene(QGraphicsPixmapItem *);
    void getAngle(double angleX, double angleY);
    void set_temp_picture(int x ,int y,QPixmap pix, unsigned int countdown);
    void game_timer_connector(); // Связь между таймером и GUI для отрисовки временных единиц и т.п.
    void set_points(unsigned int points);
    void set_missed(unsigned int missed);
};

#endif // WIDGET_H
