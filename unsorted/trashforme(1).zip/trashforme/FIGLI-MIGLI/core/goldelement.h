#ifndef GOLDELEMENT_H
#define GOLDELEMENT_H

#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class goldElement : public abstractElement
{
    Q_OBJECT
public:
    goldElement( QSize size, int formWidth, int formHeight );
public:
    void Change ( void );

};


#endif // GOLDELEMENT_H
