#include "pirateelement.h"
pirateElement::pirateElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/Pirate.png").scaled(size);
}

/* Функция которая изменяет положение элемента */
void pirateElement::Change( void ){
    this->x = x + this->right;
    this->y = start_y + 100*cos(x/50);
    this->item->setPos(x,y);
    this->change_entrance();
}
