#include "myqgraphicsview.h"

#include <QPointF>
#include <QDebug>

MyQGraphicsView::MyQGraphicsView(QWidget *parent) :
    QGraphicsView(parent)
{
    this->setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
    this->setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
}

void MyQGraphicsView::mousePressEvent(QMouseEvent * e)
{

    mousepressed = 1;
    startX = e->globalX();
    startY = e->globalY();
    //qDebug() << "mousepress!!!!11111111111";
}

void MyQGraphicsView::mouseReleaseEvent(QMouseEvent * e)
{
    emit push();
    mousepressed = 0;
    int changeX = e->globalX() - startX;
    int changeY = e->globalY() - startY;
    if(changeX != 0 && changeY != 0){
        emit swipeAngle(changeX  / sqrt(changeY*changeY + changeX*changeX),  -1* changeY  / sqrt(changeY*changeY + changeX*changeX) );
    }
    else
    {
        emit push_without_swipe();
    }
}
