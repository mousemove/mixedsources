#include "appleshell.h"

appleShell::appleShell(QSize size, int formWidth, int formHeight, double x, double y, double angle):abstractShell(size,formWidth,formHeight,x,y,angle)
{
    PixMap =  QPixmap(":/images/Apple.png").scaled(size);
   // this->charges = 2; выставка количества зарядов
}

void appleShell::Change(){
    if (active){
        this->x = x + 5*angleX;
        this->y = this->y - 5*angleY;
        this->item->setPos( x,y );
        this->change_entrance();
    }
}


