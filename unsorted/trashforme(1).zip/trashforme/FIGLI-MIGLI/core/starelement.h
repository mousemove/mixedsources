#ifndef STARELEMENT_H
#define STARELEMENT_H

#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class starElement : public abstractElement
{
    Q_OBJECT
public:
    starElement( QSize size, int formWidth, int formHeight );
public:
    void Change ( void );

};


#endif // STARELEMENT_H
