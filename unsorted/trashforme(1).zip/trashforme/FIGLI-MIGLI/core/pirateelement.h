#ifndef PIRATEELEMENT_H
#define PIRATEELEMENT_H

#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class pirateElement : public abstractElement
{
    Q_OBJECT
public:
    pirateElement( QSize size, int formWidth, int formHeight );
public:
    void Change ( void );

};

#endif // PIRATEELEMENT_H
