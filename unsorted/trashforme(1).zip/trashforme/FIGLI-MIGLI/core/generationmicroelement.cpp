#include "generationmicroelement.h"

generationMicroElement::generationMicroElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/Globe.png").scaled(size);
    this->health_points  = 1;
    this->posMov = 1;
}

/* Функция которая изменяет положение элемента */
void generationMicroElement::Change( void ){
    this->y = y + this->up;
    this->item->setPos(x,y);
    this->change_entrance();
}

