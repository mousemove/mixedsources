#include "generationelement.h"

generationElement::generationElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/Globe.png").scaled(size);
    this->health_points  = 1;
    timer = new QTimer;
    timer->setInterval(1200);
    connect(timer,SIGNAL(timeout()),this,SLOT(timer_function()));
    timer->start();
}

/* Функция которая изменяет положение элемента */
void generationElement::Change( void ){
    this->x = x + this->right;
    this->item->setPos(x,y);
    this->change_entrance();
}


void generationElement::timer_function(){
    emit add_bomb_el(x+(size.width()/2),y);
}
