#ifndef HEALTHELEMENT_H
#define HEALTHELEMENT_H

#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class healthElement : public abstractElement
{
    Q_OBJECT
public:
    healthElement( QSize size, int formWidth, int formHeight );
public:
    void Change ( void );

};
#endif // HEALTHELEMENT_H
