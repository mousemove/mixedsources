#include "game_logic.h"

game_logic::game_logic(QObject *parent,int width, int height ) : QObject(parent), width(width), height(height)
{
    qDebug() << width << height;
    timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(timer_function()));
    timer->setInterval(10);
    timer->start();

}

void game_logic::add_element(elements_enum element)
{
    switch(element){
    case BAT:
    {
        batElement * bat = new batElement( QSize( width/15, width/15 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
        break;
    case PIRATE:
    {
        pirateElement * bat = new pirateElement( QSize( width/15, width/15 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
        break;
    case STAR:
    {
        starElement * bat = new starElement( QSize( width/15, width/15 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
        break;
    case HEALTH:
    {
        healthElement * bat = new healthElement( QSize( width/30, width/30 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
        break;
    case GOLD:
    {
        goldElement * bat = new goldElement( QSize( width/12, width/12 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
        break;
    case BIG:
    {
        bigElement * bat = new bigElement( QSize( width/10, width/10 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        connect(bat,SIGNAL(add_static_element(double,double)),this,SLOT(add_static_element(double,double)));
        emit set_in_scene(bat);
        elements.push_back(bat);
    }
    case GEN:
    {
        generationElement * bat = new generationElement( QSize( width/10, width/10 ),width,height );
        connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
        connect(bat,SIGNAL(add_bomb_el(double,double)),this,SLOT(add_bomb_el(double,double)));
        emit set_in_scene(bat);
        // Предустанока без рандома наверху
        bat->setY(bat->getSize().height());
        bat->getQGPI()->setY(bat->getSize().height()); //todo нужен метод объеденяющий вот это все
        //Предустановка без рандома наверху
        elements.push_back(bat);
    }
        break;
    }
}

void game_logic::timer_function(){
    static int i = 0;

    if( !exShell) {
        new_shell();
        exShell = 1;
    }
    if ( 0 ==  (i % 135) ) {
        /* Пока добавляем элемент так */
        add_element( (game_logic::elements_enum)(qrand() %  7) );
        //add_element( GEN );

    }
    i++;
    /* Обработка терпил */

    QVector<abstractElement *>::iterator it = elements.begin();
    for(;it != elements.end();it++){
        (*it)->Change();
    }
    /*А теперь удаляем */
    it = elementsToDelete.begin();
    for(;it != elementsToDelete.end();it++){
        elements.removeOne(*it);
        (*it)->stopTimer();
        missed++;
        emit repaintMissed(missed);
    }


    /* Обработка снарядов */
    QVector<abstractShell *>::iterator itShell = shells.begin();
    for(;itShell != shells.end();itShell++){
        (*itShell)->Change();
    }

    /* А теперь удаляем */
    itShell = shellsToDelete.begin();
    for(;itShell != shellsToDelete.end();itShell++){
        shells.removeOne(*itShell);
        // delete *it; todo добавить деструктор
    }
    shellsToDelete.clear();
    elementsToDelete.clear();
    /* Получили "очищенный" вариант снарядов и терпил */
    /* Вызываем функцию check_clashes() для получения пар столкнувшихся */
    check_clashes();
    /* А теперь обрабатываем вектор пар снаряд-терпила */
    processing_clashes();
}

/* НЕ РАБОТАЮЩАЯ ФУНКЦИЯ! ВЕРНЕЕ, ОТКЛЮЧЕННАЯ ОТ ВСЕГО В ДАННЫЙ МОМЕНТ!!!!!!!!!!!!!!!!! */
/* НЕ РАБОТАЮЩАЯ ФУНКЦИЯ! ВЕРНЕЕ, ОТКЛЮЧЕННАЯ ОТ ВСЕГО В ДАННЫЙ МОМЕНТ!!!!!!!!!!!!!!!!! */
/* НЕ РАБОТАЮЩАЯ ФУНКЦИЯ! ВЕРНЕЕ, ОТКЛЮЧЕННАЯ ОТ ВСЕГО В ДАННЫЙ МОМЕНТ!!!!!!!!!!!!!!!!! */
/* НЕ РАБОТАЮЩАЯ ФУНКЦИЯ! ВЕРНЕЕ, ОТКЛЮЧЕННАЯ ОТ ВСЕГО В ДАННЫЙ МОМЕНТ!!!!!!!!!!!!!!!!! */
/* НЕ РАБОТАЮЩАЯ ФУНКЦИЯ! ВЕРНЕЕ, ОТКЛЮЧЕННАЯ ОТ ВСЕГО В ДАННЫЙ МОМЕНТ!!!!!!!!!!!!!!!!! */
void game_logic::delete_element_from_goodbye(abstractElement * bat){
    elements.takeAt(  elements.indexOf( bat  )  );
    emit delete_in_scene(bat->getQGPI());
    delete bat;
}

/* с этой уже все норм*/
void game_logic::add_element_to_kill(abstractElement * bat){
    disconnect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
    emit delete_in_scene(bat->getQGPI());
    elementsToDelete.push_back(bat);
}

void game_logic::new_shell()
{
    game_logic::shells_enum bashell = (game_logic::shells_enum)(qrand() %  2) ;
    switch(bashell){
    case APPLE:
    {
        appleShell * shell = new appleShell(QSize( width/30, width/30 ),width,height,0,0,0);
        activeShell = shell;
        emit set_in_scene_shell( shell );
    }
        break;
    case TOMATO:
    {
        smileShell * shell = new smileShell(QSize( width/30, width/30 ),width,height,0,0,0);
        activeShell = shell;
        emit set_in_scene_shell( shell );
    }
        break;
    }
}

void game_logic::push_shell(double angleX, double angleY){
    shells.push_back(   activeShell   );
    activeShell->active = 1; //toDo -> to private
    activeShell->setAngle(angleX, angleY) ;
    if (points <  activeShell->getCost()) points = 0;
    else  points = points - activeShell->getCost();
    emit repaintPoints(points);
    connect(activeShell,SIGNAL(shell_goodbye(abstractShell*)),this, SLOT(add_shell_to_kill(abstractShell*)));
    new_shell();
}


void game_logic::add_shell_to_kill(abstractShell * bat){
    disconnect(bat,SIGNAL(shell_goodbye(abstractShell*)),this, SLOT(add_shell_to_kill(abstractShell*)));
    emit delete_in_scene(bat->getQGPI());
    shellsToDelete.push_back(bat);
}

void game_logic::check_clashes(){
    /* Цикл проверки столкновения мишеней и снарядов */
    QVector<abstractElement *>::iterator it = elements.begin();
    for(;it != elements.end();it++){
        if ((*it)->getEntrance()){
            QVector<abstractShell *>::iterator itShell = shells.begin();
            for(;itShell != shells.end();itShell++){
                /* Выполняем проверку на столкновение и обработку столкновения */
                /* todo реализовать функцию clash у мишеней и снарядов */
                /* Временные данные для сложения с QSize().width etc */
                /* Перепилить в единое инициализирование!!!! */
                double shellX1 =  (*itShell)->getX();
                double shellY1 = (*itShell)-> getY();
                double elementX1 = (*it)->getX();
                double elementY1 = (*it)->getY();

                double shellX2 =  (*itShell)->getX() + (*itShell)->getSize().width();
                double shellY2 = (*itShell)-> getY() +(*itShell)->getSize().height();
                double elementX2 = (*it)->getX()  +(*it)->getSize().width() ;
                double elementY2 = (*it)->getY() + (*it)->getSize().height();
                /* Проверка */
                if ( shellX2 < elementX1 || shellX1 > elementX2 ||
                     shellY1 > elementY2 || shellY2 < elementY1 )
                { /* NI4EG0! */  }
                else{
                    //Формируется пара
                    if ( !clashPair.contains( QPair<abstractElement *, abstractShell *>( *it, *itShell  )))
                    {
                        clashPair.push_back(  QPair<abstractElement *, abstractShell *>( *it, *itShell  ));
                    }
                }
            }
        }
    }
}


void  game_logic::processing_clashes(){
    /* Рассчитываем все парные столкновения - BETA!
        todo - реализация добрых, реализация защиты, уворота и т.п.
       Но все это уже после первичного движка.... */
    QVector<   QPair<abstractElement *, abstractShell *>   >::iterator it = clashPair.begin();
    for(;it != clashPair.end();it++){
        (*it).first->get_damage ( (*it).second );
        if ( (*it).first->getHP()  <= 0 ) {
            elementsToDelete.push_back( (*it).first ); // И все-таки такая реализация. Во избежании неприятностей....
            emit delete_in_scene(   (*it).first->getQGPI() );
            emit set_temp_picture((*it).first->getX(),(*it).first->getY(),(*it).first->getBoomPix() , (*it).first->getBoomTimer());
            points = points + (*it).first->getProfit();
            emit repaintPoints(points);
            // todo вызов setpicture VREMENNOGO В миглях!!
        }
        if ((*it).first->getHU()  > 0)
        {
            maximumMissed++;
            emit repaintMissed(missed);
        }
        if ((*it).second->getCharges() < 1){
            shellsToDelete.push_back( (*it).second );
            emit delete_in_scene(   (*it).second->getQGPI() );}
        // todo вызов setpicture VREMENNOGO В миглях!!
    }

    /* Оставшаяся очистка вектора */
    QVector<abstractElement *>::iterator itk = elementsToDelete.begin();
    for(;itk != elementsToDelete.end();itk++){
        elements.removeOne(*itk);
        (*itk)->stopTimer();
    }

    /* Обработка снарядов */
    QVector<abstractShell *>::iterator itShell = shellsToDelete.begin();
    for(;itShell != shellsToDelete.end();itShell++){
        shells.removeOne(*itShell);
    }

    /* Очистка вектора пар столкновений снаряд-терпила */
    clashPair.clear();
    elementsToDelete.clear();
    shellsToDelete.clear();
}


void game_logic::add_static_element(double x, double y){
    batElement * bat = new batElement( QSize( width/15, width/15 ),width,height );
    connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
    emit set_in_scene(bat);
    elements.push_back(bat);
}


void game_logic::add_bomb_el(double x,double y){
    generationMicroElement * bat = new generationMicroElement( QSize( width/15, width/15 ),width,height );
    connect(bat,SIGNAL(goodbye(abstractElement*)),this, SLOT(add_element_to_kill(abstractElement*)));
    emit set_in_scene(bat);
    bat->setX(x);
    bat->getQGPI()->setX(x);
    bat->setY(y);
    bat->getQGPI()->setY(y);
    bat->setUp(1);
    elements.push_back(bat);
}
