#ifndef GENERATIONELEMENT_H
#define GENERATIONELEMENT_H


#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class generationElement : public abstractElement
{
    Q_OBJECT
public:
    generationElement( QSize size, int formWidth, int formHeight );
public slots:
        void timer_function();
public:
    void Change ( void );
signals:
    void add_bomb_el(double x, double y);
};

#endif // GENERATIONELEMENT_H
