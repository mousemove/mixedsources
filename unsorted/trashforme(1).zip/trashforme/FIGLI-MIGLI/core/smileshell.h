#ifndef SMILESHELL_H
#define SMILESHELL_H

#include <QObject>
#include "abstractshell.h"
#include <QtWidgets>
#include <QDebug>
class smileShell : public abstractShell
{
    Q_OBJECT
public:
    smileShell(QSize size, int formWidth, int formHeight, double x, double y,double angle);
    void Change (  );
};

#endif // SMILESHELL_H
