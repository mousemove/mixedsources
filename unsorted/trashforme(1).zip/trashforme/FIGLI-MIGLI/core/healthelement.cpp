#include "healthelement.h"

healthElement::healthElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/health.png").scaled(size);
    this->health_points  = 1;
    this->health_up = 1;
boomPix = QPixmap(":/images/pill.png").scaled(size.height()/2,size.width()/2);
}

/* Функция которая изменяет положение элемента */
void healthElement::Change( void ){
    this->x = x + this->right;
    this->y = start_y + this->up*(x);
    this->item->setPos(x,y);
    this->change_entrance();
}

