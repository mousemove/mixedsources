#include "migli.h"

migli::migli(   )
{
    connect(this,SIGNAL(push_without_swipe()),this, SLOT(new_game()));
    connect(this,SIGNAL(swipeAngle(double,double)),this, SLOT(getAngle(double,double)));
    QTime now = QTime::currentTime();
    qsrand( now.msec()   );
}

migli::~migli()
{


}


void migli::new_game(){
    if (!game_is_start){
        game_is_start = true;
        scene = new QGraphicsScene( 0,0,this->width(),this->height() );
        int i = this->height();
        scene->addPixmap(QPixmap(":/images/look.com.ua-85876.jpg").scaled(this->width(),i));
        this->setScene(scene);
        game = new game_logic(this,this->width(),this->height());
        /* Осуществляем сигнально-слотовые соединения */
        connect(game,SIGNAL(set_in_scene(abstractElement*)),this,SLOT(slot_set_element_in_scene(abstractElement*)));
        connect(game,SIGNAL(delete_in_scene(QGraphicsPixmapItem *)),this,SLOT(slot_delete_element_in_scene(QGraphicsPixmapItem *)));
        connect(game,SIGNAL(set_in_scene_shell(abstractShell*)),this,SLOT(slot_set_shell_in_scene(abstractShell*)));
        connect(game,SIGNAL(set_temp_picture(int,int,QPixmap,uint)),this, SLOT(set_temp_picture(int,int,QPixmap,uint)));
        connect(game->timer,SIGNAL(timeout()),this,SLOT(game_timer_connector()));
        connect(game,SIGNAL(repaintPoints(uint)),this,SLOT(set_points(uint)));
        connect(game,SIGNAL(repaintMissed(uint)),this,SLOT(set_missed(uint)));
        draw_info_zone();
    }
}


void migli::slot_set_element_in_scene( abstractElement * el){
    int starty,startx; // Временные переменные
    //TODO УБРАТЬ МАГИЧЕСКИЕ ЧИСЛА
    QGraphicsPixmapItem * pix = scene->addPixmap(el->getPixItem());
    pix->setPos(el->getX(),el->getY());
    /* Выставка стартовой позиции и движения элементов */
    if (el->getPosMov() == 0){
        starty = (qrand() % (int)scene->height()) / 1.2;
        startx = ((qrand() % 2) == 1) ? -100 : scene->width();
        if (startx < 0){ el->setRight(1); } else {el->setRight(-1);}
        if (starty < (int)scene->height()/3  ){ el->setUp(1); } else {el->setUp(-1);}
    }
    else
    {
        startx = (qrand() % (int)scene->width());

        if (startx > el->getX() && startx < el->getX() + el->getSize().width())
        {

            startx = (qrand() % (int)scene->width());
            startx = startx + el->getSize().width();
        }

        if (startx > scene->width() - el->getSize().width()  ) {
            startx = startx - el->getSize().width();

        }
        starty = ((qrand() % 2) == 1) ? -100 : scene->height();
        if (starty < 0){ el->setUp(1); } else {el->setUp(-1);}
        if (startx < (int)scene->width()/2  ){ el->setRight(1); } else {el->setRight(-1);}
    }
    el->setX(startx);
    el->setY(starty);
    pix->setPos(startx , starty );
    el->SetElement(pix);
    el->setStartX(startx);
    el->setStartY(starty    );

}


void migli::slot_delete_element_in_scene(QGraphicsPixmapItem * item){
    //qDebug() << "R-M-V";
    scene->removeItem(item);
    //qDebug() <<   scene->items().count();
}

void migli::slot_set_shell_in_scene(abstractShell *el){
    QGraphicsPixmapItem * pix = scene->addPixmap(el->getPixItem());
    pix->setPos(this->width()/2 - el->getSize().width(),this->height() - el->getSize().height() );
    el->setX(this->width()/2 - el->getSize().width());
    el->setY(this->height() - el->getSize().height());
    el->SetElement(pix);
}


void migli::getAngle(double angleX, double angleY){
    // qDebug() << angleX;
    game->push_shell(angleX,angleY);

}



void migli::set_temp_picture(int x ,int y,QPixmap pix, unsigned int countdown){
    QGraphicsPixmapItem * pixI = scene->addPixmap(pix);
    pixI->setPos(x,y);
    tp.push_back( QPair<QGraphicsPixmapItem *,unsigned int>(pixI,countdown)    );

}

void migli::game_timer_connector(){
    QVector< QPair<QGraphicsPixmapItem *,unsigned int> >::iterator it = tp.begin();
    for(;it != tp.end();it++){
        (*it).second--;
        if ((*it).second <= 0) tpTempToDelete.push_back(*it);
    }
    //Обход удаления
    it = tpTempToDelete.begin();
    for(;it != tpTempToDelete.end();it++){
        scene->removeItem((*it).first);
        tp.removeOne((*it));
        delete (*it).first;
    }
    tpTempToDelete.clear();
}


void migli::draw_info_zone(){
    //nado nastroit' QFonts
    int fontSize = (scene->sceneRect().size().width()/32);
    qDebug() << fontSize;
    pointsText = scene->addText("Points: "+QString().setNum(game->points));
    pointsText->setFont(QFont("Arial",fontSize));
    pointsText->setDefaultTextColor(Qt::white);
    pointsText->setPos( 0,scene->sceneRect().bottomLeft().y()-fontSize*2  );//snizu sleva

    missedText = scene->addText("Missed: "+QString().setNum(game->missed)+"/"+QString().setNum(game->maximumMissed));
    missedText->setFont(QFont("Arial",fontSize));
    missedText->setDefaultTextColor(Qt::white);
    //    missedText->setPos(pointsText->scenePos().x() ,
    //                       scene->sceneRect().bottomLeft().y()-pointsText->sceneBoundingRect().size().height()*1.5);
    missedText->setPos(0 ,
                       0);
}

void migli::set_points(unsigned int points){
    pointsText->setPlainText("Points: "+QString().setNum(points));
}

void migli::set_missed(unsigned int missed){
    missedText->setPlainText("Missed: "+QString().setNum(missed)+"/"+QString().setNum(game->maximumMissed));
}
