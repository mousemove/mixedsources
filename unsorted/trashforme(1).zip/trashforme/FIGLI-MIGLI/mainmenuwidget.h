#ifndef MAINMENUWIDGET_H
#define MAINMENUWIDGET_H

#include <QWidget>
#include <QDebug>
#include <QtWidgets>
class mainmenuWidget : public QWidget
{
    Q_OBJECT
public:
    explicit mainmenuWidget(QWidget *parent = 0);
    ~mainmenuWidget();
private:
    QGridLayout *gridLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QLabel *label;
    QPixmap  loading_logo;
    void setupUi(   );
signals:

public slots:
};

#endif // MAINMENUWIDGET_H
