#include "abstractelement.h"

abstractElement::abstractElement(QSize size, int formWidth, int formHeight  ) : size(size), formHeight(formHeight), formWidth(formWidth)
{
    boomPix = QPixmap(":/images/Explosion.png").scaled(size);
    timer = NULL;
}

QPixmap  abstractElement::getPixItem(){
    return PixMap;
}

double abstractElement::getX(){
    return x;
}

double abstractElement::getY(){
    return y;
}

void abstractElement::setStartX(int x){
    start_x = x;

}

void abstractElement::setStartY(int y){
    start_y = y;

}


bool abstractElement::getUp(){
    return this->up;
}

bool abstractElement::getRight(){
    return this->right;
}


QSize abstractElement::getSize(){
    return size;
}


void abstractElement::change_entrance()
{
    if (this->entrance == 0 ){
        if ( this->x  > 0 && this->y > 0 &&
             this->y + this->size.height() < formHeight &&
             this->x + this->size.width() < formWidth
             ){
            this->entrance = 1; // Вошли полностью в зону рисования
        }
    }
    else
    {
        if (this->x > formWidth || this->y > formHeight ||
                this->x+ this->size.width() < 0 ||
                this->y  + this->size.height() < 0  ) leave();
    }

}

void abstractElement::leave(){

    emit goodbye(this);
}

QGraphicsPixmapItem * abstractElement::getQGPI(){
    return item;
}

void abstractElement::SetElement(QGraphicsPixmapItem * gitem ){

    item = gitem;
    x = this->item->pos().x();
    y = this->item->pos().y();

}


void abstractElement::setUp(int up){
    this->up = up;

}

void abstractElement::setRight(int right){
    this->right = right;
}

bool abstractElement::getEntrance(){
    return this->entrance;
}


void abstractElement::setX(int x){
    this->x = x;
}

void abstractElement::setY(int y){
    this->y = y;
}


int abstractElement::getHP(){
    return this->health_points;
}


/* В дальнейшем эта функция будет виртуальной или PURE VIRTUALY */
int abstractElement::get_damage(abstractShell * shell){
    shell->setCharges(shell->getCharges() - health_points);
    health_points = health_points - shell->getDamage();
    return this->health_points;
}

QPixmap abstractElement::getBoomPix(){
    return boomPix;
}

unsigned int abstractElement::getBoomTimer(){
    return boomTickTack;
}

unsigned int abstractElement::getProfit(){
    return this->profit;
}

int abstractElement:: getHU(){
    return health_up;
}


int abstractElement::getPosMov(){
    return posMov;
}


void abstractElement::stopTimer(){
    if(timer != NULL){
        timer->stop();
    }
}
