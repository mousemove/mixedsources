#ifndef ABSTRACTSHELL_H
#define ABSTRACTSHELL_H

#include <QObject>
/* Абстрактный класс снаряда */
#include <QObject>
#include <QtWidgets>
#include <QDebug>
class abstractShell : public QObject
{
    Q_OBJECT
public:
    explicit abstractShell(QSize size, int formWidth, int formHeight, double x, double y,double angleX);
protected:
    /* Позиции по X и Y снаряда */
    double x;//позиция вернего левого угла по оси X
    double y; // позиция верхнего левого угла по оси Y
    int damage_deal = 1; // дамаг!!!
    double angleX; /* угол пока в паблик реализовать get i set metody */\
    double angleY;
    unsigned int cost = 10;
    unsigned int charges = 1;   //заряды!!!!!! типо
    unsigned int posMov = 0;    //временная версия - позиционирование движения(0 - вправо/влево, 1 - вверх/вниз)
    QSize size; // Размер элемента на графической сцене
    /* Размеры формы для рисования */
    int formWidth;
    int formHeight ;
    bool entrance = true; // по аналогии с мишенями. Пока вводится но требуется ли?
    QPixmap  PixMap; // Картиночка
    QGraphicsPixmapItem * item; // Хренотень в графической сцене
    void change_entrance(); // Функция для обработки состояния entrance
    void leave();

public:
    bool active = 0;
    void setAngle(double angleX,double angleY);
    double speed;/* Скорость пока в паблик реализовать set i get metody */
    /*Возвращающие функции */
    QPixmap  getPixItem(); // Получение qgraphicspixmapitem
    QGraphicsPixmapItem * getQGPI();
    void setX(int x);
    void setY( int y);
    double getX();
    double getY();
    QSize getSize();
    int getDamage();
    int getCost();
    int getCharges();
    void setCharges(int num);
    void SetElement ( QGraphicsPixmapItem * gitem ) ;
    /* Виртуальная функция */
    virtual void Change ( void ) = 0; // Функция пересчета позиции
signals:
    void shell_goodbye(abstractShell*);
public slots:
};

#endif // ABSTRACTSHELL_H
