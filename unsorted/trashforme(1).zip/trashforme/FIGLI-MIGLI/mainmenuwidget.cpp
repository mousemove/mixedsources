#include "mainmenuwidget.h"

mainmenuWidget::mainmenuWidget(QWidget *parent) : QWidget(parent)
{
setupUi();
}

mainmenuWidget::~mainmenuWidget()
{

}

void mainmenuWidget::setupUi(   )
{

    this->resize(366, 510);
    gridLayout = new QGridLayout(this);
    gridLayout->setSpacing(6);
    gridLayout->setContentsMargins(11, 11, 11, 11);
    gridLayout->setObjectName(QStringLiteral("gridLayout"));
    pushButton = new QPushButton(this);
    pushButton->setText("PLAY STORY MODE");

    gridLayout->addWidget(pushButton, 1, 0, 1, 1);

    pushButton_2 = new QPushButton(this);
    pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
    pushButton_2->setText("PLAY FREE MODE");
    gridLayout->addWidget(pushButton_2, 2, 0, 1, 1);

    pushButton_5 = new QPushButton(this);
    pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
    pushButton_5->setText("EXIT");
    gridLayout->addWidget(pushButton_5, 5, 0, 1, 1);

    pushButton_4 = new QPushButton(this);
    pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
    pushButton_4->setText("ABOUT");
    gridLayout->addWidget(pushButton_4, 4, 0, 1, 1);

    pushButton_3 = new QPushButton(this);
    pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
    pushButton_3->setText("ALMAHACH");

    gridLayout->addWidget(pushButton_3, 3, 0, 1, 1);

    label = new QLabel(this);
    loading_logo =  QPixmap(":/images/main_logo.png");
    label->setPixmap(loading_logo);
    label->setObjectName(QStringLiteral("label"));

    gridLayout->addWidget(label, 0, 0, 1, 1);

}
