#include "figli.h"
/* КЛАСС-МАРШРУТИЗАТОР!!! */
figli::figli( )
    : QStackedWidget( )
{
    //Инициализируем виджет загрузки
    load_menu = new loadingWidget(this);
    addWidget(load_menu);
    connect(load_menu,SIGNAL(animation_end()),this,SLOT(slot_loading_animation_end()));

    //Инициализируем виджет главного меню
    main_menu = new mainmenuWidget(this);
    addWidget(main_menu);

    /* Изначально - меню загрузки */
    setCurrentWidget(load_menu);
}

figli::~figli()
{

}

void figli::slot_loading_animation_end(){
    setCurrentWidget(main_menu);
}
