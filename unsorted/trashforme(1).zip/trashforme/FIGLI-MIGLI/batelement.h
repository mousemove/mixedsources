#ifndef BATELEMENT_H
#define BATELEMENT_H

#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class batElement : public abstractElement
{
    Q_OBJECT
public:
    batElement( QSize size, int formWidth, int formHeight );
public:
    void Change ( void );

};

#endif // BATELEMENT_H
