#ifndef BIGELEMENT_H
#define BIGELEMENT_H


#include <QObject>
#include "abstractelement.h"
#include <QtWidgets>
#include <QDebug>
class bigElement : public abstractElement
{
    Q_OBJECT
public:
    bigElement( QSize size, int formWidth, int formHeight );

public:
    void Change ( void );
private:

public slots:
        void timer_function();
signals:
        void add_static_element(double x, double y);
};


#endif // BIGELEMENT_H
