#include "bigelement.h"

bigElement::bigElement(QSize  size, int formWidth, int formHeight):abstractElement(size,formWidth,formHeight)
{
    PixMap =  QPixmap(":/images/Bat.png").scaled(size);
    this->health_points  = 1;
    timer = new QTimer;
    timer->setInterval(600);
    connect(timer,SIGNAL(timeout()),this,SLOT(timer_function()));
    timer->start();
}

/* Функция которая изменяет положение элемента */
void bigElement::Change( void ){
    this->x = x + this->right;
    this->item->setPos(x,y);
    this->change_entrance();
}

void bigElement::timer_function(){
    emit add_static_element(x,y);
}


