#ifndef APPLESHELL_H
#define APPLESHELL_H

#include <QObject>
#include "abstractshell.h"
#include <QtWidgets>
#include <QDebug>
class appleShell : public abstractShell
{
    Q_OBJECT
public:
    appleShell(QSize size, int formWidth, int formHeight, double x, double y,double angle);
    void Change (  );
};


#endif // APPLESHELL_H
