#include "abstractshell.h"

abstractShell::abstractShell(QSize size, int formWidth, int formHeight, double x, double y, double angle) :  size(size), formHeight(formHeight), formWidth(formWidth) ,x(x), y(y), angleX(angle)
{

}

QPixmap  abstractShell::getPixItem(){
    return PixMap;
}

QGraphicsPixmapItem * abstractShell::getQGPI(){
    return item;
}

void abstractShell::setX(int x){
    this->x = x;
}

void abstractShell::setY( int y){
    this->y = y;
}

QSize abstractShell::getSize(){
    return size;
}


void abstractShell::SetElement ( QGraphicsPixmapItem * gitem ) {
    this->item = gitem;
}


void abstractShell::setAngle(double angleX, double angleY){
    this->angleX = angleX;
    this->angleY = angleY;
}

void abstractShell::change_entrance(){
    if (this->x > formWidth || this->y > formHeight ||
            this->x+ this->size.width() < 0 ||
            this->y  + this->size.height() < 0  ) leave();
}


void abstractShell::leave(){
    emit shell_goodbye(this);

}


double abstractShell::getX(){
    return this->x;
}

double abstractShell::getY(){
    return this->y;
}

int  abstractShell::getDamage(){
    return this->damage_deal;
}
int abstractShell::getCost(){
    return this->cost;
}


int abstractShell::getCharges(){
    return this->charges;
}

void abstractShell::setCharges(int num){
    this->charges = num;
}
