#include "graphicswidget.h"
#include "ui_graphicswidgetform.h"
#include "lib/resizescroolfilter.h"
#include <QDebug>
graphicsWidget::graphicsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::graphicsWidget)
{
    ui->setupUi(this);
    showerWidget = new shower();
    ui->scrollArea->setWidgetResizable(true);
    //  ui->scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->scrollArea->setWidget(showerWidget);
    connect(showerWidget,SIGNAL(move_up()),this,SLOT(sc_up()));
    connect(showerWidget,SIGNAL(move_down()),this,SLOT(sc_down()));
    showerWidget->setFocusPolicy(Qt::NoFocus);
    ui->scrollArea->setFocusPolicy(Qt::StrongFocus);
    ui->scrollArea->setFocus();

}

graphicsWidget::~graphicsWidget()
{
    delete ui;
}


void  graphicsWidget::sc_up(){
    ui->scrollArea->verticalScrollBar()->setValue(ui->scrollArea->verticalScrollBar()->value()+7);
}

void  graphicsWidget::sc_down(){
    ui->scrollArea->verticalScrollBar()->setValue(ui->scrollArea->verticalScrollBar()->value()-7);
}

void graphicsWidget::get_selection(){
    selection sel = showerWidget->get_select_type();
    emit select_in_db(sel);
}


void graphicsWidget::set_full_values(int p, int i, int pm, int im)
{
    showerWidget->set_full_values(p,i,pm,im);
}


void graphicsWidget::set_plot_values(QVector<double> keys_p,QVector<double> values_p,QVector<double> keys_i,QVector<double> values_i)
{

    showerWidget->set_plot_values(keys_p,values_p,keys_i,values_i);

}



void graphicsWidget::set_pie_values(QVector< QPair<QString, double> > p ,QVector< QPair<QString, double> > i){
    showerWidget->set_pie_values(p,i);
}
