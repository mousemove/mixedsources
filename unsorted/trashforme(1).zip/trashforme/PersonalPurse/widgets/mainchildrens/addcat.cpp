#include "addcat.h"
#include "ui_addcatwidget.h"

addcat::addcat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addcat)
{
    ui->setupUi(this);
}

addcat::~addcat()
{
    delete ui;
}

void addcat::swipe_position(bool p){
    this->position = p;
}

void addcat::on_pushButton_clicked()
{
    emit addCat(ui->lineEdit->text(),ui->plainTextEdit->toPlainText(),this->position);
}
