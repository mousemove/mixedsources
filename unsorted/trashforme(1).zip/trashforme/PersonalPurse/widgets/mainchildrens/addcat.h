#ifndef ADDCAT_H
#define ADDCAT_H

#include <QWidget>

namespace Ui {
class addcat;
}

class addcat : public QWidget
{
    Q_OBJECT

public:
    explicit addcat(QWidget *parent = 0);
    ~addcat();
private:
    Ui::addcat *ui;
    bool position = 0; // Переменная для позиции - добавить кд или кр
public slots:
    void swipe_position(bool p);
private slots:
    void on_pushButton_clicked();
signals:
   void addCat(QString,QString, bool);
};

#endif // ADDCAT_H
