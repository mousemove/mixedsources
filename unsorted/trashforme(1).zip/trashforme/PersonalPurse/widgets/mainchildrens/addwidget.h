#ifndef ADDWIDGET_H
#define ADDWIDGET_H

#include <QWidget>
#include <QtWidgets>
namespace Ui {
class addWidget;
}

class addWidget : public QWidget
{
    Q_OBJECT

public:
    explicit addWidget(QWidget *parent = 0);
    ~addWidget();
    bool position = 0; // Переменная для позиции - добавить кд или кр
    void clear_select_box();
    void add_select_box(QString str);
private:
    Ui::addWidget *ui;
private slots:
    void  buttonClicked();
    void swipe_swipeLabel();
signals:
    void swipe_to_cat();
    void swipe_position(bool);
    void update_cat_lists(bool);
   void add_item(QString, QDate, QString, double,bool);
};

#endif // ADDWIDGET_H
