#ifndef SHOWER_H
#define SHOWER_H

#include <QWidget>
#include <QDebug>
#include <QtWidgets>
#include <lib/scrollwidget.h>

enum selection{
    WEEK = 0,
    SEVENDAYS,
    MONTH,
    TRDAYS,
    YEAR,
    TRSXDAYS
};

namespace Ui {
class shower;
}

class shower : public scrollwidget
{
    Q_OBJECT

public:
    explicit shower(QWidget *parent = 0);
    ~shower();
private:
    Ui::shower *ui;
    selection selmode = WEEK;
    int max_p = 0;
    int max_i = 0;
public:
    selection  get_select_type();
    void set_full_values(int p, int i, int pm, int im);
    void set_plot_values(QVector<double> keys_p,QVector<double> values_p,QVector<double> keys_i,QVector<double> values_i);
    void set_pie_values(QVector< QPair<QString, double> > p ,QVector< QPair<QString, double> > i);
};


#endif // SHOWER_H
