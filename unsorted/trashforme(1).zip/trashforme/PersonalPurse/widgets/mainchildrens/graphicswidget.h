#ifndef GRAPHICSWIDGET_H
#define GRAPHICSWIDGET_H

#include <QWidget>
#include "shower.h"
namespace Ui {
class graphicsWidget;
}

class graphicsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit graphicsWidget(QWidget *parent = 0);
    void get_selection();
    ~graphicsWidget();
private:
    shower * showerWidget;
    Ui::graphicsWidget *ui;

public slots:
    void  sc_up();
    void  sc_down();
    void set_full_values(int p,int i,int pm, int im);
    void set_plot_values(QVector<double> keys_p,QVector<double> values_p,QVector<double> keys_i,QVector<double> values_i);
    void set_pie_values(QVector< QPair<QString, double> > p ,QVector< QPair<QString, double> > i);
signals:
    void select_in_db(selection);
};

#endif // GRAPHICSWIDGET_H
