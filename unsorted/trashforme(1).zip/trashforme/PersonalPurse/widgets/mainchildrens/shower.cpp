#include "shower.h"
#include "ui_showerform.h"
#include "lib/resizescroolfilter.h"
enum colors{
    WHITE = Qt::green,
   // BLACK = Qt::black,
};

int max_from_qvd(QVector<double>& vec){
    int max = 0;
    for(double db : vec){
        if (db > max) max = db;
    }
    return max;
}


shower::shower(QWidget *parent) :
    scrollwidget(parent),
    ui(new Ui::shower)
{
    ui->setupUi(this);
    ui->widget->installEventFilter(new ResizeScroolFilter(this,parent));
    // ui->widget_2->installEventFilter(new ResizeScroolFilter(this,parent));
    //  ui->widget->setFocusPolicy(Qt::NoFocus);
    //ui->widget_2->setFocusPolicy(Qt::NoFocus);
    ui->widget->addGraph();

    //ui->widget_2->addGraph();
}

shower::~shower()
{
    delete ui;
}

selection  shower::get_select_type()
{
    return this->selmode;
}

void shower::set_full_values(int p,int i,int pm,int im){
    qDebug() << p << i;
    ui->label->setText("Общий доход: "+ QString().setNum(i));
    ui->label_2->setText("Общие расходы: "+ QString().setNum(p));
    // Перерисовка графиков
    max_i = i;
    max_p = p;
    qDebug() << "PM,IM" << pm , im;
    ui->widget->yAxis->setRange(0,pm);
    ui->widget->replot();
}

void shower::set_plot_values(QVector<double> keys_p,QVector<double> values_p,QVector<double> keys_i,QVector<double> values_i){
    QVector<QString> labels;
    QVector<double> ticks;
    ticks << 1 << 2 << 3 << 4 << 5 << 6 << 7;
    labels << "Понедельник" << "Вторник" << "Среда" << "Четверг" << "Пятница" << "Суббота" << "Воскресенье";
    ui->widget->graph(0)->setData(keys_p,values_p);
    //ui->widget_2->graph(0)->setData(keys_i,values_i);
    ui->widget->graph(0)->setPen(QPen(Qt::blue));
    ui->widget->graph(0)->setBrush(QBrush(QColor(240, 255, 200)));
    ui->widget->graph(0)->setAntialiasedFill(false);
    ui->widget->graph(0)->setName("Расходы:");
    ui->widget->xAxis->setAutoTicks(false);
    ui->widget->xAxis->setAutoTickLabels(false);
    ui->widget->xAxis->setTickVector(ticks);
    ui->widget->xAxis->setTickVectorLabels(labels);
    ui->widget->xAxis->setTickLabelRotation(25);
    ui->widget->xAxis->setTickLength(0, 1);
    ui->widget->xAxis->grid()->setVisible(true);
    ui->widget->xAxis->setRange(1, 7.5);
    ui->widget->yAxis->setRange(0,max_from_qvd(values_p)+max_from_qvd(values_p)/10);
    ui->widget->graph(0)->setScatterStyle((QCPScatterStyle::ScatterShape)(10));
    //    ui->widget->graph(0)->setLineStyle(((QCPGraph::LineStyle)(5)));
    //    ui->widget_2->graph(0)->setScatterStyle((QCPScatterStyle::ScatterShape)(10));

    //    ui->widget_2->graph(0)->setLineStyle((QCPGraph::LineStyle)(5));
    // ui->widget->yAxis->setRangeReversed(1);
    // ui->widget_2->yAxis->setRangeReversed(1);
    //ui->widget_2->replot();
    ui->widget->replot();

    //ui->widget_2

    ui->widget_2->addItem("1", Qt::red,5);
    ui->widget_2->addItem("2", Qt::black,5);
    ui->widget_2->addItem("3", Qt::yellow,90);
    //ui->widget_2->setPalette(QPalette(Qt::black));
    // ui->widget_2->setAutoFillBackground(true);
    ui->widget_2->setStyleSheet(
                "painter {"
                "      alignment: center;"
                " }"


                );
    //    ui->widget_2->setCords(100,100,this->width()/1.5,this->height()/1.5);
    //    ui->widget_2->addPiece("Item1",QColor(200,10,50),34);
    //    ui->widget_2->addPiece("Item2",Qt::green,27);
    //    ui->widget_2->addPiece("Item3",Qt::cyan,14);
    //    ui->widget_2->addPiece("Item4",Qt::yellow,7);
    //    ui->widget_2->addPiece("Item5",Qt::blue,4);
}

void shower::set_pie_values(QVector< QPair<QString, double> > p ,QVector< QPair<QString, double> > i){
    qDebug() << " kek_2";
 colors color = WHITE;
    ui->widget_2->clear();
    ui->widget_2->setType(Nightcharts::Pie);//{Histogramm,Pie,Dpie};
    for( QPair<QString, double>& pair : p)
    {
        ui->widget_2->addItem(       pair.first+"("+QString().setNum(pair.second)+")" , QColor(rand() % 255,rand() % 255,rand() % 255),(pair.second/max_p)*100 );
    }

}
