#include "addwidget.h"
#include "ui_addwidgetform.h"

addWidget::addWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addWidget)
{
    ui->setupUi(this);
    ui->dateEdit->setDate( QDate().currentDate(  ) );
    connect(ui->pushButton,SIGNAL(clicked()),this, SLOT(buttonClicked()));
    connect(ui->pushButton_2 ,SIGNAL(clicked()),this, SLOT(buttonClicked()));
    connect(ui->label,SIGNAL(swipeUp()),this,SLOT(swipe_swipeLabel()));
    connect(ui->label,SIGNAL(swipeDown()),this,SLOT(swipe_swipeLabel()));
    connect(ui->label,SIGNAL(swipeLeft()),this,SLOT(swipe_swipeLabel()));
    connect(ui->label,SIGNAL(swipeRight()),this,SLOT(swipe_swipeLabel()));
}

addWidget::~addWidget()
{
    delete ui;
}

void addWidget::buttonClicked(){
    QString str = ((QPushButton*)sender())->text();
    if (str == "Добавить"){
        emit swipe_to_cat();
    }
    if (str == "Добавить!"){
        qDebug() << "Добавить материал";
        emit add_item(ui->plainTextEdit->toPlainText(), ui->dateEdit->date(), ui->comboBox->currentText(), ui->doubleSpinBox->value(), position);
    }
}

void addWidget::clear_select_box(){
    ui->comboBox->clear();
}

void addWidget::add_select_box(QString str){
    ui->comboBox->addItem(str);
}

/* Меняем все! */
void addWidget::swipe_swipeLabel(){
    position = !position;
    emit swipe_position(position);
    qDebug() <<"SWIIIIIPEEEEEE";
    if (position){
        ui->label->setText("<center>РАСХОД</center>");
        ui->label_4->setText("Категория расхода");
        ui->label_5->setText("Расход");
    }
    else
    {
        ui->label->setText("<center>ДОХОД</center>");
        ui->label_4->setText("Категория дохода");
        ui->label_5->setText("Доход");
    }
    emit update_cat_lists(position);
}
