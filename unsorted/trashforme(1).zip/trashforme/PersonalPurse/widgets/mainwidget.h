#ifndef MAINWIDGET_H
#define MAINWIDGET_H
/* Виджет - маршрутизатор для информационных виджетов */
#include <QtWidgets>
#include "mainchildrens/graphicswidget.h"
#include "mainchildrens/addwidget.h"
#include "mainchildrens/addcat.h"
#include "lib/database.h"
#include "QObject"
#include "QDate"
class mainwidget : public QTabWidget
{
    Q_OBJECT
public:
    explicit mainwidget(QWidget *parent = 0);
    ~mainwidget();
private:
    QStackedWidget * stackedAdd;
    graphicsWidget * gW;
    addWidget * aW;
    addcat * acW;
    database * db;
signals:
    void send_full_values(int,int,int,int);
    void send_plot_values(QVector<double>,QVector<double>,QVector<double>,QVector<double>);
    void send_pie_values(QVector< QPair<QString, double> >,QVector< QPair<QString, double> >);
public slots:
    void set_add_item();
    void set_add_cat();
    void on_add_cat(QString name, QString cat, bool position);
    void update_list_positions(bool p);
    void add_item_to_db(QString commentary, QDate date, QString name, double cost,bool position);
    void get_selection_from_db(selection sel);

private:
    void update_ptc_list();
    void update_inc_list();

};

#endif // MAINWIDGET_H
