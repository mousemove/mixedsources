#include "mainwidget.h"

mainwidget::mainwidget(QWidget *parent) : QTabWidget(parent)
{
    /* Создание суб-виджетов */

    gW = new graphicsWidget(this);

    connect(gW,SIGNAL(select_in_db(selection)),this,SLOT(get_selection_from_db(selection)));
    connect(this,SIGNAL(send_full_values(int,int,int,int)),gW, SLOT(set_full_values(int,int,int,int)));
    connect(this,SIGNAL(send_plot_values(QVector<double>,QVector<double>,QVector<double>,QVector<double>)),
            gW, SLOT(set_plot_values(QVector<double>,QVector<double>,QVector<double>,QVector<double>)));
    connect(this,SIGNAL(send_pie_values(QVector<QPair<QString,double> >,QVector<QPair<QString,double> >)),
            gW,SLOT(set_pie_values(QVector<QPair<QString,double> >,QVector<QPair<QString,double> >)));
    aW = new addWidget(this);
    connect(aW,SIGNAL(swipe_to_cat()),this,SLOT(set_add_cat()));
    acW = new addcat(this);
    connect(aW,SIGNAL(swipe_position(bool)), acW, SLOT(swipe_position(bool)));
    connect(aW,SIGNAL(add_item(QString,QDate,QString,double,bool)),this,SLOT(add_item_to_db(QString,QDate,QString,double,bool)));
    connect(acW,SIGNAL(addCat(QString,QString,bool)),this,SLOT(on_add_cat(QString,QString,bool)));

    db = new database(this);
    db->select_income_cat();
    db->select_purch_cat();
    update_inc_list();
    stackedAdd = new QStackedWidget(this);
    stackedAdd->addWidget(aW);
    stackedAdd->addWidget(acW);
    stackedAdd->setCurrentWidget(aW);
    /* Выставка суб-виджетов */
    this->addTab(gW, "Отображение");
    this->addTab(stackedAdd, "Добавить");
    QFile file(":/images/tw.qss");
    file.open(QFile::ReadOnly);
    this->setStyleSheet(QLatin1String(file.readAll()));
    connect(aW,SIGNAL(update_cat_lists(bool)),this,SLOT(update_list_positions(bool)));
    gW->get_selection();
}
mainwidget::~mainwidget()
{

}

void mainwidget::set_add_item(){
    stackedAdd->setCurrentWidget(aW);
}

void mainwidget::set_add_cat(){
    stackedAdd->setCurrentWidget(acW);
}


void mainwidget::on_add_cat(QString name, QString cat, bool position){
    qDebug() << cat << "top kek";
    stackedAdd->setCurrentWidget(aW);
    /* Добавляем категорию дохода */
    if (!position){
        qDebug() << db->add_income_cat(name,cat);
        update_inc_list();
    }
    else
    {
        qDebug() << db->add_purch_cat(name,cat);
        update_ptc_list();
    }
}


void mainwidget::update_ptc_list(){
    aW->clear_select_box();
    QVector< database::purch_cat>::iterator it = db->pcs.begin();
    for(;it < db->pcs.end();it++){
        aW->add_select_box(it->name);
    }
}

void mainwidget::update_inc_list(){
    // qDebug() << "uil";
    aW->clear_select_box();
    QVector< database::income_cat>::iterator it = db->ics.begin();
    for(;it < db->ics.end();it++){
        aW->add_select_box(it->name);
    }

}


void mainwidget::update_list_positions(bool p){
    if (!p){
        update_inc_list();
    }
    else
    {
        update_ptc_list();
    }
}

void mainwidget::add_item_to_db(QString commentary, QDate date, QString name, double cost,bool position)
{

    if (!position){
        qDebug() << db->add_income(commentary,date,db->select_income_cat_from_name(name),cost);
        gW->get_selection();
    }
    else
    {
        qDebug() << db->add_purch(commentary,date,db->select_purch_cat_from_name(name),cost);
        gW->get_selection();
    }
}

void mainwidget::get_selection_from_db(selection sel){
    int i;
    int b;
    if (sel  == WEEK)
    {
        QVector<double> keys_i;
        QVector<double> values_i;
        QVector<double> keys_p;
        QVector<double> values_p;
        QVector< QPair<QString, double> > cats_p;
        QVector< QPair<QString, double> > cats_i{};
        QDate cur_date = QDate::fromJulianDay(QDate::currentDate().toJulianDay());
        QDate first_date = QDate::fromJulianDay(QDate::currentDate().toJulianDay() - QDate::currentDate().dayOfWeek() + 1) ;
        // qDebug() << cur_date << first_date;
        db->select_incomes(first_date,cur_date);
        db->select_purches(first_date,cur_date);
        /* Внутренние обработки */
        emit send_full_values(db->pselect.summ,db->iselect.summ, db->pselect.max,db->iselect.max);
        for (i = first_date.toJulianDay(); i < cur_date.toJulianDay()+1; i++ )
        {

            b = i - first_date.toJulianDay() + 1;
            qDebug() << b;
            db->select_incomes(QDate::fromJulianDay(i),QDate::fromJulianDay(i));
            keys_i.push_back(b);
            values_i.push_back(db->iselect.summ);
            db->select_purches(QDate::fromJulianDay(i),QDate::fromJulianDay(i));
            keys_p.push_back(b);
            values_p.push_back(db->pselect.summ);

        }
        emit send_plot_values(keys_p,values_p,keys_i,values_i);//
        /* Обработки по категориям(циклы по стандарту c++11/14 */
        for(  database::purch_cat cat  : db->pcs)
        {
            qDebug() <<   db->select_purches(first_date,cur_date,&cat);
            cats_p.push_back({cat.name,db->pselect.summ});
        }

        //*посылка(инкаумы пока 0)
        emit send_pie_values(cats_p, cats_i);
    }


}
