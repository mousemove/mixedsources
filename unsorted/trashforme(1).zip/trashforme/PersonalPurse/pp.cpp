#include "pp.h"
/* КЛАСС-МАРШРУТИЗАТОР!!! */
pp::pp( )
    : QStackedWidget( )
{
    //Инициализируем виджет загрузки
    load_menu = new loadingWidget(this);
    addWidget(load_menu);
    connect(load_menu,SIGNAL(animation_end()),this,SLOT(slot_loading_animation_end()));
    main_widget = new mainwidget(this);
    addWidget(main_widget);


    /* Изначально - главное меню */
    setCurrentWidget(load_menu);
}

pp::~pp()
{

}

void pp::slot_loading_animation_end(){
    qDebug() << "load done!!!!!";
                setCurrentWidget(main_widget);
}
