#ifndef DATABASE_H
#define DATABASE_H

#include <QObject>
#include <QtWidgets>
#include <QDebug>
#include <QtSql>
class database : public QObject
{
    Q_OBJECT
public:
    /* Категории */
    struct purch_cat{
        int id;
        QString name;
        QString commentary;
    };
    struct income_cat{
        int id;
        QString name;
        QString commentary;
    };
    /* Покупки и доходы */
    struct purch{
        double cost;
        purch_cat cat;
        QDate date;
        QString commentary;
    };
    struct income{
        double cost;
        income_cat cat;
        QDate date;
        QString commentary;
    };
    /* Выборки покупок и доходов */
    struct purch_select{
        int max = 0;
        int summ = 0;
        int min = 0;
        QVector<purch> purches;
        QDate dateStart;
        QDate dateFinish;
    };

    struct income_select{
        int max = 0;
        int summ = 0;
        int min = 0;
        QVector<income> incomes;
        QDate dateStart;
        QDate dateFinish;
    };
    /* Вектора категорий */
    QVector<income_cat> ics;
    QVector<purch_cat> pcs;
    /*Выборки*/
    purch_select pselect;
    income_select iselect;

    /* Вектора выборок ??? мб ограничиться 1 выборкой? todo */
    QVector<income_select> iselectvector;
    QVector<purch_select> pselectvector;

public:
    explicit database(QObject *parent = 0);
    bool add_income_cat(QString name, QString commentary);
    bool add_purch_cat(QString name, QString commentary);
    bool select_income_cat();
    bool select_purch_cat();
    bool add_income(QString commentary, QDate date, income_cat cat, double cost);
    bool add_purch(QString commentary, QDate date, purch_cat cat, double cost);
    bool select_incomes( QDate startDate, QDate finishDate, income_cat * cat = 0  );
    bool select_purches( QDate startDate, QDate finishDate, purch_cat * cat = 0  );
    purch_cat select_purch_cat_from_id(int id);
    purch_cat select_purch_cat_from_name(QString name);
    income_cat select_income_cat_from_id(int id);
    income_cat select_income_cat_from_name(QString name);

private:
    void createtables();




signals:

public slots:
};

#endif // DATABASE_H
