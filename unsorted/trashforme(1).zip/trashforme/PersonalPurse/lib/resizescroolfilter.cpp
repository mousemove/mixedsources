#include "resizescroolfilter.h"
#include <QDebug>
ResizeScroolFilter::ResizeScroolFilter(QObject * parent, QWidget *widget) : QObject(parent), widget(widget)
{

}

bool ResizeScroolFilter::eventFilter(QObject * po, QEvent * pe){

    if (pe->type() == QEvent::MouseButtonPress){
        QMouseEvent * me = static_cast<QMouseEvent *>(pe);
        this->parent()->event(me);
        return true;
    }
    if (pe->type() == QEvent::MouseButtonRelease){
        QMouseEvent * me = static_cast<QMouseEvent *>(pe);
        this->parent()->event(me);
        return true;
    }
    if (pe->type() == QEvent::MouseMove ){
        QMouseEvent * me = static_cast<QMouseEvent *>(pe);
        if (me->buttons() == Qt::LeftButton ){
            this->parent()->event(pe);
            return true;
        }
    }
    return false;
}
