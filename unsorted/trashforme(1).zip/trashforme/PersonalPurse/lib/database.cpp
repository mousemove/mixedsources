#include "database.h"



static bool createConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("gameatrisdb");

    db.setUserName("PersonalPurse");
    db.setHostName("PersonalPurse");
    db.setPassword("PersonalPurse");
    if (!db.open()) {
        //qDebug() << "Cannot open database:" << db.lastError();
        return false;
    }
    QStringList lst = db.tables();
    foreach (QString str,lst){
        // qDebug() << "Ta6JIU#A:" << str;
    }
    return true;
}


database::database(QObject *parent) : QObject(parent)
{
    createtables();
}

void database::createtables()
{
    if ( !createConnection( ) ) {
        // qDebug() << "EГГОГ - 6A3E XAHA"; // ошибка соединения с базой данных
    }
    QSqlQuery query;
    // Создание таблиц в базе данных
    QString   str  = "CREATE TABLE purchases ( "
                     "id INTEGER PRIMARY KEY NOT NULL, "
                     "cost   DOUBLE, "
                     "id_ps_group  INTEGER, "
                     "commentary  TEXT,"
                     "date DATE "
                     ");";
    if (!query.exec(str)) {
        //  qDebug() << "Unable to create a table";
    }

    str  = "CREATE TABLE income ( "
           "id INTEGER PRIMARY KEY NOT NULL, "
           "profit   DOUBLE, "
           "id_inc_group  INTEGER, "
           "commentary  TEXT, "
           "date DATE "
           ");";
    if (!query.exec(str)) {
        // qDebug() << "Unable to create a table";
    }

    str  = "CREATE TABLE income_cat ( "
           "id INTEGER PRIMARY KEY NOT NULL, "
           "name VARCHAR(64), "
           "commentary  TEXT "
           ");";
    if (!query.exec(str)) {
        // qDebug() << "Unable to create a table";
    }

    str  = "CREATE TABLE profit_cat ( "
           "id INTEGER PRIMARY KEY NOT NULL, "
           "name VARCHAR(64), "
           "commentary  TEXT "
           ");";
    if (!query.exec(str)) {
        // qDebug() << "Unable to create a table";
    }


}


bool database::add_income_cat(QString name, QString commentary){
    QSqlQuery query;
    //Проверка есть ли уже в БД такой тип расхода
    QString str = "SELECT * FROM income_cat WHERE "
                  "name = '"+name+"';";

    //qDebug() << str;
    if( !query.exec(str) ) {
        return 0;
    }
    else
    {
        if (!query.next()){
            //   qDebug() << query.value(query.record().indexOf("id")).toInt();
            str = "INSERT INTO income_cat(name, commentary) "
                  "VALUES('"+name+"','"+commentary+"')";
            // qDebug() << str ;
            if (!query.exec(str)) {
                return 0;
            }
            else{
                select_income_cat();
                select_purch_cat();
                return 1;
            }
        }
        return 0;
    }
}


bool database::add_purch_cat(QString name, QString commentary){
    QSqlQuery query;
    //Проверка есть ли уже в БД такой тип дохода
    QString str = "SELECT * FROM profit_cat WHERE "
                  "name = '"+name+"';";

    // qDebug() << str;
    if( !query.exec(str) ) {
        return 0;
    }
    else
    {
        if (!query.next()){
            // qDebug() << query.value(query.record().indexOf("id")).toInt();
            str = "INSERT INTO profit_cat(name, commentary) "
                  "VALUES('"+name+"','"+commentary+"')";
            //qDebug() << str ;
            if (!query.exec(str)) {
                return 0;
            }
            else{
                select_income_cat();
                select_purch_cat();
                return 1;
            }
        }
        return 0;
    }
}


bool database::select_income_cat(){
    ics.clear();

    QString result;
    QSqlQuery query;
    QString str = "SELECT * FROM income_cat; ";
    if (!query.exec(str)) {
        return 0;
    }
    else
    {
        QSqlRecord rec = query.record();
        int id;
        QString commentary;
        QString name;
        while(query.next()){
            id = query.value(rec.indexOf("id")).toInt();
            commentary =  query.value(rec.indexOf("commentary")).toString();
            name = query.value(rec.indexOf("name")).toString();
            income_cat it;
            it.id = id;
            it.commentary = commentary;
            it.name = name;
            ics.push_back(it);
        }

        return 1;

    }
}

bool database::select_purch_cat(){
    pcs.clear();

    QString result;
    QSqlQuery query;
    QString str = "SELECT * FROM profit_cat; ";
    if (!query.exec(str)) {
        return 0;
    }
    else
    {
        QSqlRecord rec = query.record();
        int id;
        QString commentary;
        QString name;
        while(query.next()){
            id = query.value(rec.indexOf("id")).toInt();
            commentary =  query.value(rec.indexOf("commentary")).toString();
            name = query.value(rec.indexOf("name")).toString();
            purch_cat it;
            it.id = id;
            it.commentary = commentary;
            it.name = name;
            pcs.push_back(it);
        }

        return 1;

    }
}

bool database::add_income(QString commentary, QDate date, income_cat cat, double cost){
    QSqlQuery query;
    if (!query.next()){



        QString str = "INSERT INTO income(profit,id_inc_group,commentary,date) "
                      "VALUES("+QString().setNum(cost)+","+QString().setNum(cat.id)+",'"+commentary+"','"+date.toString("yyyy-MM-dd")+"');";
        // qDebug() << str ;
        if (!query.exec(str)) {
            return 0;
        }
        else{
            return 1;
        }
    }
    return 0;
}


bool database::add_purch(QString commentary, QDate date, purch_cat cat, double cost){
    QSqlQuery query;
    if (!query.next()){
        QString str = "INSERT INTO purchases(cost,id_ps_group,commentary,date) "
                      "VALUES("+QString().setNum(cost)+","+QString().setNum(cat.id)+",'"+commentary+"','"+date.toString("yyyy-MM-dd")+"');";
        //qDebug() << str ;
        if (!query.exec(str)) {
            return 0;
        }
        else{
            return 1;
        }
    }
    return 0;
}


database::purch_cat database::select_purch_cat_from_id(int id){
    QVector<purch_cat>::iterator it = pcs.begin();
    for(;it != pcs.end();it++){
        if ((*it).id == id){return *it;}
    }

}

database::purch_cat database::select_purch_cat_from_name(QString name){
    QVector<purch_cat>::iterator it = pcs.begin();
    for(;it != pcs.end();it++){
        if ((*it).name == name){return *it;}
    }
}

database::income_cat database::select_income_cat_from_id(int id){
    QVector<income_cat>::iterator it = ics.begin();
    for(;it != ics.end();it++){
        if ((*it).id == id){return *it;}
    }
}

database::income_cat database::select_income_cat_from_name(QString name){
    QVector<income_cat>::iterator it = ics.begin();
    for(;it != ics.end();it++){
        if ((*it).name == name){return *it;}
    }
}

bool database::select_incomes(QDate startDate, QDate finishDate, income_cat *cat   ){
    QSqlQuery query;
    QString str;
    if (cat == 0){
        str = "SELECT * FROM income WHERE date >= '"+startDate.toString("yyyy-MM-dd")+"' AND date <= '"+finishDate.toString("yyyy-MM-dd")+" ' ; ";
    }
    else
    {
        str = "SELECT * FROM income WHERE date >= '"+startDate.toString("yyyy-MM-dd")+"' AND"
                                                                                      " date <= '"+finishDate.toString("yyyy-MM-dd")+" AND inc_group = "+QString().setNum(cat->id)+" ' ; ";
    }
    //  qDebug() << str;
    //  QString str = "SELECT * FROM income ; ";
    if (!query.exec(str)) {
        return 0;
    }
    else
    {
        iselect.incomes.clear();
        iselect.summ = 0;
        iselect.min =0;
        iselect.max =0;
        QSqlRecord rec = query.record();
        int id;
        QString commentary;
        QDate date;
        double cost;
        int cat_id;
        iselect.dateStart = startDate;
        iselect.dateFinish = finishDate;
        while(query.next()){
            income income_example;
            id = query.value(rec.indexOf("id")).toInt();
            commentary =  query.value(rec.indexOf("commentary")).toString();
            date = query.value(rec.indexOf("date")).toDate();
            cost = query.value(rec.indexOf("profit")).toDouble();
            cat_id = query.value(rec.indexOf("id_inc_group")).toInt();
            income_example.date = date;
            income_example.commentary = commentary;
            income_example.cost = cost;
            income_example.cat = select_income_cat_from_id(cat_id);
            iselect.incomes.push_back( income_example );



        }

        // Формирование общего дохода
        QVector<income>::iterator it = iselect.incomes.begin();
        for(;it != iselect.incomes.end(); it++)
        {
            iselect.summ += (*it).cost;
            if (((*it).cost) > iselect.max) iselect.max = (*it).cost;
            if (((*it).cost) < iselect.min) iselect.min = (*it).cost;
        }


        return 1;

    }

}


bool database::select_purches( QDate startDate, QDate finishDate, purch_cat * cat )
{
    QSqlQuery query;
    QString str;
    if (cat == 0){
        str = "SELECT * FROM purchases WHERE date >= '"+startDate.toString("yyyy-MM-dd")+"' AND date <= '"+finishDate.toString("yyyy-MM-dd")+"' ; ";
    }
    else
    {
        str = "SELECT * FROM purchases WHERE date >= '"+startDate.toString("yyyy-MM-dd")+"'"
                                                                                         " AND date <= '"+finishDate.toString("yyyy-MM-dd")+"' AND id_ps_group = "+QString().setNum(cat->id)+" ; ";
    }
    //qDebug() << str;
    //  QString str = "SELECT * FROM purchases ; ";
    if (!query.exec(str)) {
        return 0;
    }
    else
    {
        pselect.purches.clear();
        pselect.summ = 0;
        pselect.min =0;
        pselect.max =0;
        QSqlRecord rec = query.record();
        int id;
        QString commentary;
        QDate date;
        double cost;
        int cat_id;
        pselect.dateStart = startDate;
        pselect.dateFinish = finishDate;
        while(query.next()){
            purch income_example;
            id = query.value(rec.indexOf("id")).toInt();
            commentary =  query.value(rec.indexOf("commentary")).toString();
            date = query.value(rec.indexOf("date")).toDate();
            cost = query.value(rec.indexOf("cost")).toDouble();
            cat_id = query.value(rec.indexOf("id_ps_group")).toInt();
            income_example.date = date;
            income_example.commentary = commentary;
            income_example.cost = cost;
            // qDebug() << "next~" << cat_id;
            income_example.cat = select_purch_cat_from_id(cat_id);
            pselect.purches.push_back( income_example );
        }
        // Формирование общего расхода
        QVector<purch>::iterator it = pselect.purches.begin();
        for(;it != pselect.purches.end(); it++)
        {
            pselect.summ += (*it).cost;
            if (((*it).cost) > pselect.max) pselect.max = (*it).cost;
            if (((*it).cost) < pselect.min) pselect.min = (*it).cost;
        }

        return 1;

    }

}




