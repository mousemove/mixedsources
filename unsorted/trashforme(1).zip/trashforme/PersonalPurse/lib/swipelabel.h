#ifndef SWIPELABEL_H
#define SWIPELABEL_H

#include <QtWidgets>

class swipeLabel : public QLabel
{
    Q_OBJECT
public:
    swipeLabel( QWidget * parent = 0);
    ~swipeLabel();
public slots:
    void mousePressEvent(QMouseEvent * e);
    void mouseReleaseEvent(QMouseEvent *e);
private:
    bool mousepressed = 0;
    int startX,startY;
signals:
    void push();
    void push_without_swipe();
    void swipeUp();
    void swipeLeft();
    void swipeDown();
    void swipeRight();
};

#endif // SWIPELABEL_H
