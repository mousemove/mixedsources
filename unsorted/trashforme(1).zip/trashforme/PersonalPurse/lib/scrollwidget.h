#ifndef SCROLLWIDGET_H
#define SCROLLWIDGET_H

#include <QWidget>
#include <QtWidgets>
class scrollwidget : public QWidget
{
    Q_OBJECT
public:
    explicit scrollwidget(QWidget *parent = 0);
public slots:
    void mousePressEvent(QMouseEvent * e);
    void mouseMoveEvent(QMouseEvent *e);
private:
    bool mousepressed = 0;
    int startX,startY;
signals:
    void move_up();
    void move_down();

};

#endif // SCROLLWIDGET_H
