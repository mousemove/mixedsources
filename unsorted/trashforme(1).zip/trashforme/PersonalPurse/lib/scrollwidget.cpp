#include "scrollwidget.h"
#include <QDebug>
scrollwidget::scrollwidget(QWidget *parent) : QWidget(parent)
{

}

void scrollwidget::mousePressEvent(QMouseEvent * e)
{

    mousepressed = 1;
    startX = e->globalX();
    startY = e->globalY();
}

void scrollwidget::mouseMoveEvent(QMouseEvent * e)
{
    if (mousepressed){
        if (e->type() == QEvent::MouseMove){
            if (startY > e->globalY()){
                emit move_up();
            }
            if (startY < e->globalY()){
                emit move_down();
            }
        }
    }
    startX = e->globalX();
    startY = e->globalY();
    //    emit push();
    //    mousepressed = 0;
    //    int changeX = e->globalX() - startX;
    //    int changeY = e->globalY() - startY;
    //    if(changeX != 0 && changeY != 0){
    //        if (fabs(changeX) > fabs(changeY))
    //        {
    //            if (changeX < 0 ){    qDebug() << "up";
    //                emit swipeLeft();
    //            }
    //            else{    qDebug() << "up";
    //                emit swipeRight();
    //            }
    //        }
    //        if (fabs(changeX) < fabs(changeY))
    //        {

    //            if (changeY < 0 ){
    //                   qDebug() << "up";
    //                emit swipeUp();

    //            }
    //            else{    qDebug() << "up";
    //                emit swipeDown();
    //            }

    //        }
    //    }
    //    else
    //    {
    //         emit push_without_swipe();
    //    }
}
