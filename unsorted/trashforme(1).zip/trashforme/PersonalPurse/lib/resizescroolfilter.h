#ifndef RESIZESCROOLFILTER_H
#define RESIZESCROOLFILTER_H

#include <QObject>
#include <QtWidgets>
class ResizeScroolFilter : public QObject
{
    Q_OBJECT
public:
    explicit ResizeScroolFilter( QObject * widget,QWidget *parent = 0);
protected:
    virtual bool eventFilter(QObject * po, QEvent * pe);
private:
    QScrollArea * area;
    QWidget * widget;

signals:

public slots:
};

#endif // RESIZESCROOLFILTER_H
