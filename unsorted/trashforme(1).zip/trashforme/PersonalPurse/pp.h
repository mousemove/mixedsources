#ifndef WIDGET_H
#define WIDGET_H
/* КЛАСС-МАРШРУТИЗАТОР!!! */
#include <QWidget>
#include <QtWidgets>
#include "widgets/loadingwidget.h"
#include "widgets/mainwidget.h"
class pp : public QStackedWidget
{
    Q_OBJECT
private:
    /* Виджеты используемые в программе */
    loadingWidget * load_menu; // Виджет для 5 секундной загрузки - старта программы
    mainwidget * main_widget;
public:
    pp( );
    ~pp();
private slots:

public slots:
void slot_loading_animation_end();
signals:
};

#endif // WIDGET_H
